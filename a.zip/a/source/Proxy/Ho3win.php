<?php
/*
 @Reza_id_Tell: 
*/
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$ping1 = array("29.1","0.9","7","34","204","387","67.9","35.9","81","45","992","467","623","23.9","52","101","322","3","0.5","84","588","45.9","978","74","29","1322","1928","160","11","13","289","111","641","107","506","459","549","679","193","459","768","137","332","0.2","715","90","476","11.2","17","15.4","81.9","401","36.4","48","87","896","1246","1.7","3.5","6.8","9.2","578","393","176","432","1.9","7.3","10.5","19.3","27.6","37.9","93.8","31.5","6.9","73.5","281","207","45.8","16.3","18.1","49.8","35.6","69.5","678","24.6","0.10","87.5","1589","79.7","198");
$Lorex1 = array(
'🇯🇵 ژاپن 🇯🇵',
   '🇷🇺 روسیه 🇷🇺',
'🇳🇴 نروژ 🇳🇴',
'🇺🇸 آمریکا 🇺🇸',
'🇮🇹 ایتالیا 🇮🇹',
'🇫🇷 فرانسه 🇫🇷',
'🇩🇪 آلمان 🇩🇪',
'🇬🇧 بریتانیا 🇬🇧',
'🇳🇱 هلند 🇳🇱',
'🇨🇦 کانادا 🇨🇦',
'🇨🇳 چین 🇨🇳',
'🇸🇪 سوئدن 🇸🇪',
'🇮🇳 هند 🇮🇳',
'🇹🇷 ترکیه 🇹🇷',
'🇧🇷 برزیل 🇧🇷',
'🇧🇪  🇧🇪',
'🇮🇪 ایرلند 🇮🇪',
'🇪🇸 اسپانیا 🇪🇸',
'🇻🇳 ویتنام 🇻🇳',
'🇵🇪 پرو 🇵🇪',
'🇨🇭 سوئیس 🇨🇭',
'🇵🇦 پاناما 🇵🇦',
'🇦🇹 اتریش 🇦🇹',
'🇺🇾 اروگوئه 🇺🇾',
'🇵🇦 پاناما 🇵🇦',
'🇫🇮 فنلاند 🇫🇮',
'🇩🇰 دانمارک 🇩🇰',
'🇬🇷 یونان 🇬🇷',
'🇺🇦 اوکراین 🇺🇦',
'🇷🇴 رومانیا 🇷🇴',
'🇵🇱 لهستان 🇵🇱',
'🇮🇷 ایران 🇮🇷',
);
$strings = array(
'🧊',
   '⛵️',
'🤩',
'🥳',
'👾',
'🤖',
'🎃',
'👻',
'🌟',
'💫',
'✨',
'⚡',
'☄',
'💥',
'🍟',
'⛩',
'🎪',
'🗼',
'🎡',
'🎭',
'🎊',
'🎉',
);
 
 $strings2 = array(
'✅',
'✔',
);

$strings3 = array(
'🎃',
'👽',
'👹',
'👺',
'☠️',
'🤖',
'🔥',
'💫',
'🌞',
'🎊',
'🫀',
'🩸',
);

$strings4 = array(
'🔴',
'🟠',
'🟡',
'🟢',
'🔵',
'🟣',
'⚫',
'⚪',
);


shuffle($strings);
$emj1=reset($strings);

shuffle($ping1);
$Ping =reset($ping1);

shuffle($strings2);
$emj2=reset($strings2);

shuffle($strings3);
$emj3=reset($strings3);

shuffle($strings4);
$emj4=reset($strings4);

shuffle($Lorex1);
$Lorex=reset($Lorex1);

shuffle($strings5);
$emj5=reset($strings5);

shuffle($chann);
$mat1=reset($chann);

shuffle($matn1);
$mat2=reset($matn1);
 
define('API_KEY',"[*[TOKEN]*]");//توکن  

function getPage($url) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_REFERER, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function bot($method,$datas=[]){
    $url = 'https://api.telegram.org/bot'.API_KEY.'/'.$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
 }
}

/*
 @Reza_id_Tell : @#
*/
//----------------
$update = json_decode(file_get_contents("php://input"));
$chat_id = $update->message->chat->id;
$text = $update->message->text;
$result = json_decode($get, true);
//-----------------
$channel = "[*[CHANNEL]*]";// آیدی کانال بدون @

function send($proxy){
       global $emj1;
       global $emj2;
       global $emj3;
       global $emj4;
       global $emj5;
        global $Lorex;
       global $Ping;
       global $mat1;
        global $mat2;
	global $channel;
	bot('sendmessage',['chat_id'=>"@$channel",'text'=>"$emj1 ＮＥＷ  🇵 🇷 🇴 🇽 🇾
#پروکسی_جدید

$emj1 پروکسی : اختصاصی 
$emj4 مکان : $Lorex 
📊 پینگ : $Ping
$emj3 @$channel",
 'parse_mode'=>"HTML",
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"$emj4 اتصال به پروکسی",'url'=>"$proxy"]],
]
])
]);
    $file = fopen('proxy.txt', "a") or die("Unable to open file!");
    fwrite($file, "$proxy\n");
    fclose($file);
}

$x=0;

    $ch = curl_init("https://t.me/s/sdfsdfsdf111sdf");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
]);
$data = curl_exec($ch);
curl_close($ch);


    $ch = curl_init("https://t.me/s/kingporoxy");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
]);
$data2 = curl_exec($ch);


    $ch = curl_init("https://t.me/s/proxy_forall");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
]);
$data3 = curl_exec($ch);



    $ch = curl_init("https://t.me/Myporoxy");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
]);


$data4 = curl_exec($ch);


preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $data, $matches2);
preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $data2, $matches);
preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $data3, $matche);
preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $data4, $match);


$y=1;
for($x=0;$x<=1000;$x++){
$proxy=$matches2[0][$x];   $proxy=str_Replace("&amp;","&",$proxy); 
	    if(strpos($proxy,'joinchat') !== false){
	        
	    }else{
		if( strpos($proxy,'proxy?server') !== false )
		{ 
		    
			    if(strpos($list,"$proxy") !== false){
			        
			    }else{
			$proxy_list.="<$y>$proxy</$y><br>";$y++;		    

			    }
			    			    $list.="$proxy";
		    
		    
		}
}
if($proxy==null){
    $x=1001;
}
}
for($x=0;$x<=1000;$x++){
$proxy=$matches[0][$x];   $proxy=str_Replace("&amp;","&",$proxy); 
	    if(strpos($proxy,'joinchat') !== false){
	        
	    }else{
		if( strpos($proxy,'proxy?server') !== false )
		{ 
		    
			    if(strpos($list,"$proxy") !== false){
			        
			    }else{
			$proxy_list.="<$y>$proxy</$y><br>";$y++;		    

			    }
			    			    $list.="$proxy";
		    
		    
		}
}
if($text1 == "/help"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🇮🇷 سلام به ربات پروکسی گذار کانال نسخه فارسی خوش آمدید 

🔔 کانال تنظیم شده : @[*[CHANNEL]*]

📚 راهنمای استفاده از ربات :
1⃣ ابتدا ربات را در کانال @[*[CHANNEL]*] مدیر کنید و دسترسی ارسال پیام را برای ربات باز کنید

2⃣ پس از ادمین کردن ربات داخل ربات دستور /new یا پیام دلخواه ارسال کنید مثلاً بگویید ربات

⚙ نسخه ربات : 2
",
'parse_mode'=>"html",
'reply_to_message_id'=>$message_id,
]);
}
if($proxy==null){
    $x=1001;
}
}
for($x=0;$x<=1000;$x++){
$proxy=$match[0][$x];   $proxy=str_Replace("&amp;","&",$proxy); 
	    if(strpos($proxy,'joinchat') !== false){
	        
	    }else{
		if( strpos($proxy,'proxy?server') !== false )
		{ 
		    
			    if(strpos($list,"$proxy") !== false){
			        
			    }else{
			$proxy_list.="<$y>$proxy</$y><br>";$y++;		    

			    }
			    			    $list.="$proxy";
		    
		    
		}
}
if($proxy==null){
    $x=1001;
}
}
for($x=0;$x<=1000;$x++){
$proxy=$matche[0][$x];   $proxy=str_Replace("&amp;","&",$proxy); 
	    if(strpos($proxy,'joinchat') !== false){
	        
	    }else{
		if( strpos($proxy,'proxy?server') !== false )
		{ 
		    
			    if(strpos($list,"$proxy") !== false){
			        
			    }else{
			$proxy_list.="<$y>$proxy</$y><br>";$y++;		    

			    }
			    			    $list.="$proxy";
		    
		    
		}
}
if($proxy==null){
    $x=1001;
}
}

if($y!=1){
$rand=rand(1,$y);
$proxy=get_string_between($proxy_list, "<$rand>", "</$rand>");
send($proxy);echo "created by @LorexTeam & @Mr_Ho3win 
$proxy ";
}
 
?>