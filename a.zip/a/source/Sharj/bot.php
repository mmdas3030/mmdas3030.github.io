<?php
ob_start();

define('API_KEY','[*[TOKEN]*]');//add token
//---------------ch_botsazi-----------------//
function bot($method,$datas=[]){
	$url = "https://api.telegram.org/bot".API_KEY."/".$method;
	$ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
 function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function Forward($kojashe, $azkoja, $kodommsg){
	bot('forwardmessage',[
	'chat_id'=>$kojashe,
	'from_chat_id'=>$azkoja,
	'message_id'=>$kodommsg
	]);
}
function sendphoto($chat_id, $photo, $caption){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
function sendAction($chat_id, $action){
bot('sendChataction',[
'chat_id'=>$chat_id,
'action'=>$action
]);
}
function senddocument($chat_id, $document, $caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption,
 ]);
 }
function LeaveChat($chat_id){
bot('LeaveChat',[
'chat_id'=>$chat_id
]);
}
function GetChat($chat_id){
	bot('GetChat',[
	'chat_id'=>$chat_id
	]);
	}
function EditMessageCaption($chat_id,$message_id,$caption){
	 bot('editMessageCaption',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'caption'=>$caption,
]);
}
function sendsticker($chat_id, $sticker){
 bot('sendsticker',[
 'chat_id'=>$chat_id,
 'sticker'=>$sticker,
 ]);
 }
function RandomString(){
        $length=8;
        $characters='0123456789QWERTYUIOPASDFGHJKLZXCVBNMabcdefghijklmnopqrstuvwxyz';
        $string='';
            for($p=0;$p<$length;$p++){
            $string.=$characters[mt_rand(0,strlen($characters))];
            }
            return $string;
        } 
//--------ch_botsazi---------//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
mkdir("data/$from_id");
mkdir("data/$chat_id");
mkdir("data");
$from_id = $message->from->id;
$first_name = $message->from->first_name;
$username = $message->from->username;
$textmassage = $message->text;
$message_id = $update->message->message_id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$rpto = $update->message->reply_to_message->forward_from->id;
$forward_chat_username = $update->message->forward_from_chat->username;
$fromid = $update->callback_query->from->id;
$chatid = $update->callback_query->message->chat->id;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
$message_id22 = $update->callback_query->message->message_id;
$photo = $update->message->photo;
//-------------Mac_team--------------//
$ali = file_get_contents("data/$from_id/ali.txt");
$name = file_get_contents("data/$from_id/name.txt");
$idad = file_get_contents("data/$from_id/idad.txt");
$num = file_get_contents("data/$from_id/num.txt");
$idse = file_get_contents("data/$from_id/sendch.txt");
$emt = file_get_contents("data/$from_id/em.txt");
$blocklist = file_get_contents("data/blocklist.txt");
$list = file_get_contents("users.txt");
$charge = file_get_contents("data/$from_id/charge.txt");

$left = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$channel1&user_id=$fromid"));
$tchq = $left->result->status;
//---------------newbots------------//
$ADMIN = [*[ADMIN]*];//id admin
$channel = "@[*[CHANNEL]*]";//id channel ba @
$token = "[*[TOKEN]*]";//add token
$channel1 = "@[*[CHANNEL]*]";
$channel2 = "@[*[CHANNEL]*]";//id channel tabligh bedon @
$idbot = "[*[USERNAME]*]";//id bot bedon @
$mention = "[$first_name](tg://user?id=$from_id)";

$tab = json_decode(file_get_contents("../../lib/Jsons/tab.json"));


$off_on = file_get_contents("bot.txt");
$admin = [*[ADMIN]*]; 

///////////------//////////-----------////////
if(file_exists("data/mtnstart.txt")){
$mtnstart = file_get_contents("data/mtnstart.txt");
}else{
$mtnstart = "متن پیش فرض استارت - قابل تنظیم از مدیریت";
}
///////////------//////////-----------////////
if(file_exists("data/mtnzir.txt")){
$mtnzir = file_get_contents("data/mtnzir.txt");
}else{
$mtnzir = "متن پیش فرض زیرمجموعه - قابل تنظیم از مدیریت";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt2.txt")){
$mmbrsabt2 = file_get_contents("data/mmbrsabt2.txt");
}else{
$mmbrsabt2 = "40";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt22.txt")){
$mmbrsabt22 = file_get_contents("data/mmbrsabt22.txt");
}else{
$mmbrsabt22 = "80";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt3.txt")){
$mmbrsabt3 = file_get_contents("data/mmbrsabt3.txt");
}else{
$mmbrsabt3 = "50";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt33.txt")){
$mmbrsabt33 = file_get_contents("data/mmbrsabt33.txt");
}else{
$mmbrsabt33 = "100";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt4.txt")){
$mmbrsabt4 = file_get_contents("data/mmbrsabt4.txt");
}else{
$mmbrsabt4 = "100";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt44.txt")){
$mmbrsabt44 = file_get_contents("data/mmbrsabt44.txt");
}else{
$mmbrsabt44 = "200";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt5.txt")){
$mmbrsabt5 = file_get_contents("data/mmbrsabt5.txt");
}else{
$mmbrsabt5 = "200";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt55.txt")){
$mmbrsabt55 = file_get_contents("data/mmbrsabt55.txt");
}else{
$mmbrsabt55 = "400";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt6.txt")){
$mmbrsabt6 = file_get_contents("data/mmbrsabt6.txt");
}else{
$mmbrsabt6 = "300";
}
///////////------//////////-----------////////
if(file_exists("data/mmbrsabt66.txt")){
$mmbrsabt66 = file_get_contents("data/mmbrsabt66.txt");
}else{
$mmbrsabt66 = "600";

#===============================================================================

if(strpos($off_on,"false") !== false && $from_id != $admin){
 	bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات خاموش میباشد 😴
چند دقیقه بعد دوباره امتحان کنید ⏰",
]);   
 return false;
}
if($left == "left"){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ شما عضو کانال ما نیستید ⛔

💠 برای ادامه کار با ربات باید عضو کانال 
نیو ربات بشوید .

$channel
$channel2

🚫 جهت عضویت روی دکمه بررسی عضویت کلیک کنید
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"بررسی عضویت 🔍",'callback_data'=>'lockch']
],
]
])
]);
}else{
}
if($textmassage == "/start"){
   $user = file_get_contents('Member.txt');
    $members = explode("\n",$user);
    if (!in_array($from_id,$members)){
      $add_user = file_get_contents('Member.txt');
      $add_user .= $from_id."\n";
file_put_contents("data/$chat_id/membrs.txt", "0");
file_put_contents("data/$chat_id/charge.txt", "1");
     file_put_contents('Member.txt',$add_user);
    }
file_put_contents("data/$from_id/ali.txt", "no");
	bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$tab",
]);
	bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$mtnstart",
'parse_mode'=>'Markdown',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
]
])
]);
#===============================================================================
}
elseif(strpos($blocklist, "$from_id") !== false  ) {
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🛑شما به خاطر رعایت نکردن قوانین از ربات مسدود شدید 

❇️لطفا پیام دوباره ارسال نکنید",
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
])
]);
#===============================================================================
}
elseif($textmassage == "/rules"){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"",
'parse_mode'=>'Markdown',
]);
#===============================================================================
}
elseif($textmassage =="برگشت ↩"){
file_put_contents("data/$from_id/ali.txt","no");
file_put_contents("data/$from_id/idch.txt","no");
file_put_contents("data/$from_id/name.txt","no");
file_put_contents("data/$from_id/idad.txt","no");
file_put_contents("data/$from_id/num.txt","no");
file_put_contents("data/$from_id/etel.txt","no");
	bot('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"با موفقیت به منوی اصلی برگشتیم ↪️
 لطفا انتخاب کنید⤵️",	'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
]
])
]);
#===============================================================================
}
elseif($textmassage == "حساب کاربری👮‍♂"){
$name = $update->callback_query->from->first_name;
	bot('Sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"
🎫 حساب کاربری شما در ربات :

🗣 نام : $name
🆔 شناسه : from_id
💎 موجودی شما : $charge سکه
👥 تعداد زیر مجموعه ها : $sea نفر

ℹ️ شما میتوانید با دعوت دیگران از طریق لینک دعوت اختصاصی خودت اقدام به افزایش موجودی و تبدیل سکه به شارژ کنید

🎊 ربات 🍉 هندوّنه | شارژّ 🎁 برای جذب اعتماد شما کانالی برای گزارش خرید ها تهیه کرده است که گزارش تمام خرید ها در کانال @ ارسال میشوند",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>'Markdown',
]);

#===============================================================================
}
elseif($textmassage == "راهنما📜"){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🔖 راهنمای خرید شارژ از ربات
🔸 ضمن تشکر از شما کاربرگرامی برای انتخاب ربات جهت خرید شارژ اپراتور؛

1️⃣ برای خرید شارژ ابتدا از طریق دکمه استعلام شارژها ، شارژ موجود را مشاهده و سپس اقدام به خرید کنید.

2️⃣ اگر تعداد سکه های شما برابر با تعداد سکه های لازم برای بود ، کد شارژ به صورت تصویری برای شما ارسال خواهد شد.

4️⃣ با دکمه خرید شارژ میتوانید شارژ دریافت کنید",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>'Markdown',
]);
#===============================================================================
}
elseif($data == "lockch"){
$name = $update->callback_query->from->first_name;
if($tchq == 'member' or $tchq == 'creator' or $tchq == 'administrator'){
   
bot('Sendmessage',[
'chat_id'=>$chatid,
'text'=>"✅ حساب شما با موفقیت تایید شد.",
'parse_mode'=>'Markdown',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
]
])
]);
#===============================================================================
}else{
        bot('answercallbackquery',[
            'callback_query_id' => $update->callback_query->id,
            'text' => "❌ هنوز داخل کانال ☆$channel1☆ عضو نیستی.",
            'show_alert' =>true
        ]);
}
}
elseif($textmassage == "زیرمجموعه گیری👥"){
bot('Sendphoto',[
'chat_id'=>$chatid,
'photo'=>"https://t.me/perti_land/74",
'caption'=>"$.mtnzir

http://t.me/$idbot?start=$from_id",

]);
bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "بنر شما ارسال شد",
                'show_alert' => false
            ]);
#===============================================================================
        } 
elseif (strpos($textmassage, '/start') !== false){
        $newid = str_replace("/start ", "", $textmassage);
        if ($from_id == $newid) {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text'=>"
با عرض معذرت شما نمیتوانید معرف خود باشید😑",
            ]);
        } elseif (strpos($list, "$from_id") !== false) {
            SendMessage($chat_id, "شما قبلا عضو ربات شدید و مجددا نمیشه 😶");
        } else {
            $charge = file_get_contents("data/$newid/charge.txt");
            $getcharge = $charge + 1;
            file_put_contents("data/$newid/charge.txt", $getcharge);
$sea = file_get_contents("data/$newid/membrs.txt");
            $get = $sea + 1;
            file_put_contents("data/$newid/membrs.txt", $get);
             $user = file_get_contents('users.txt');
            $members = explode("\n", $user);
            if (!in_array($from_id, $members)) {
                $add_user = file_get_contents('users.txt');
                $add_user .= $from_id . "\n";
file_put_contents("data/$from_id
/membrs.txt", "0");
                file_put_contents("data/$from_id/charge.txt", "0.5");
                file_put_contents('users.txt', $add_user);
            }
            file_put_contents("data/$from_id/ali.txt", "No");
            	bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$tab",
]); 
            sendmessage($chat_id, "تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️");
            
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$mtnstart",
'parse_mode'=>'Markdown',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"دریافت شارژ🛍"]],
[['text'=>"حساب کاربری👮‍♂️"],['text'=>"زیرمجموعه گیری👥"]],
[['text'=>"افزایش موجودی🛒"],['text'=>"راهنما📜"]],
[['text'=>"تراکنش های اخیر📲"],['text'=>"پشتیبانی☎️"],['text'=>"استعلام شارژ💸"]],
]
])
]);
#===============================================================================
bot('Sendmessage',[
'chat_id'=>$newid,
'text'=>"
کاربری با لینک شما عضو ربات شد
",
]);
#===============================================================================
}
}
elseif($textmassage == "پشتیبانی☎️" or $textmassage == "/sup"){
file_put_contents("data/$from_id/ali.txt","pay");
file_put_contents("data/$from_id/Mjkr.txt","no");
	bot('sendMessage',[
	'chat_id'=>$chat_id,
'text'=>"👮🏻 همکاران ما در خدمت شما هستن !
 
🔘 در صورت وجود نظر , ایده , گزارش مشکل , پیشنهاد , ایراد سوال , یا انتقاد میتوانید با ما در ارتباط باشید 
💬 لطفا پیام خود را به صورت فارسی و روان ارسال کنید",
'parse_mode'=>'Markdown',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"برگشت ↩"]
],
]
])
]);
}elseif($ali == "pay"){            
if($textmassage != "برگشت ↩"){
                    file_put_contents("data/$from_id/ali.txt","none");
Forward($ADMIN,$chat_id,$message_id);
bot('sendmessage',[       
'chat_id'=>$chat_id,
			'text'=>"✅ پیام شما ارسال شد.",
      'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"برگشت ↩"]
],
]
])
	]);
}
}
elseif($rpto != "" && $chat_id == $ADMIN){
bot('sendmessage',[
'chat_id'=>$rpto,
'text'=>"📬<code>پاسخ پیام شما از طرف پشتیبانی</code>

$textmassage",
'parse_mode'=>'HTML',
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما به کاربر مورد نظر ارسال شد📮",
'parse_mode'=>'HTML',
]);
#===============================================================================
}
elseif($textmassage == ""){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"™️тeαм_ρeятı👻
",
]);
#===============================================================================

#===============================================================================
}
elseif($textmassage == "پیام به کاربر🔉" or $textmassage == "/gh"){
file_put_contents("data/$from_id/ali.txt","info");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا شناسه کاربر را وارد کنید💉",
]);
#-------------------------------------------------------------------------
}
elseif($ali == "info"){
file_put_contents("data/$from_id/ali.txt","sendpm");
file_put_contents("data/$from_id/info.txt","$textmassage");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا پیام خود را وارد کنید✏",
]);
#-------------------------------------------------------------------------------
}
elseif($ali == "sendpm"){
file_put_contents("data/$from_id/ali.txt","none");
file_put_contents("data/$from_id/sendpm.txt","$textmassage");
$sendpm = file_get_contents("data/$from_id/sendpm.txt");
$info = file_get_contents("data/$from_id/info.txt");
bot('Sendmessage',[
'chat_id'=>$info,
'text'=>"📬<code>پیامی از طرف پشتیبانی</code>

$sendpm",
'parse_mode'=>'HTML',
]);
#-------------------------------------------------------------------------------
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما به کاربر مورد نظر ارسال شد📮",
'parse_mode'=>'HTML',
]);
#===============================================================================
}
elseif($textmassage == "اضافه کردن شارژ 🔋"){
file_put_contents("data/$from_id/ali.txt","addshar");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا ایدی عددی کاربر رو ارسال کنید",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"پنل"]
],
]
])
]);
#-----------------------------------------------------------------------------
}
elseif($ali == "addshar"){
file_put_contents("data/$from_id/addshar.txt",$textmassage);
file_put_contents("data/$from_id/ali.txt","numofshar");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا تعداد شارژ رو ارسال کنید",
]);
#-------------------------------------------------------------------------------
}
elseif($ali == "numofshar"){
$shar = file_get_contents("data/$from_id/addshar.txt");
$tshar = file_get_contents("data/$shar/charge.txt");
$getshar = $tshar + $textmassage;
file_put_contents("data/$shar/charge.txt", $getshar);
        file_put_contents("data/$chat_id/ali.txt", "");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"شارژ موردنظر به کاربر $shar به تعداد $textmassage اضافه شد",
]);
#===================================================================
}
elseif($textmassage == "/panel" && $from_id == $ADMIN){
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"به پنل مدیریت ربات وارد شدید 🔐",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
    ['text'=>"امار📊"]
    ],
[
    ['text'=>"فوروارد همگانی🔊"],['text'=>"پیام به کاربر🔉"]
    ],
[
    ['text'=>"تنظیم کانال〽️"],['text'=>"تنظیم کانال اعلانات🔅"]
    ],
[
    ['text'=>"حذف کانال⚠️"],['text'=>"حذف کانال اعلانات⚠️"]
],
[
    ['text'=>"افزودن شارژ➕"],['text'=>"تنظیم امتیاز 🚧"]
],
[
    ['text'=>"تنظیم متن استارت ⚡️"],['text'=>"تنظیم متن زیرمجموعه ⚡️"]
],
[
    ['text'=>"بلاک📌"],['text'=>"آنبلاک📍"]
],
[
    ['text'=>"خاموش کردن ربات🚫"],['text'=>"روشن کردن ربات♨️"]
],
[
    ['text'=>"برگشت ↩"]
],
]
])
]);
#===============================================================================
}
elseif($textmassage == "بلاک📌"){
file_put_contents("data/$from_id/ali.txt","shar");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا ایدی فرد مورد نظر را ارسال کنید",
]);
#-----------------------------------------------------------------------------
}
elseif($ali == "shar"){
file_put_contents("data/$from_id/shar.txt","$textmassage");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
ایدی $textmassage بلاک شد از ربات",
]);
#------------------------------------------------------------------------
$adduser = file_get_contents("data/blocklist.txt");
$adduser .= $textmassage . "\n";
file_put_contents("data/blocklist.txt", $adduser);
file_put_contents("data/$from_id/ali.txt","no");
$id11 = file_get_contents("data/$from_id/shar.txt");
bot('Sendmessage',[
'chat_id'=>$id11,
'text'=>"ارتباط شما با سرور ما قطع شد و نمیتوانید از بات استفاده کنید 😪",
]);
#============================================================================
}
elseif($textmassage == "آنبلاک📍"){
file_put_contents("data/$from_id/ali.txt","sharr");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا ایدی عددی کاربر مورد نظر رو ارسال کنید",
]);
#-------------------------------------------------------------------------------
}
elseif($ali == "sharr"){
$newlist = str_replace($textmassage, "", $blocklist);
        file_put_contents("data/blocklist.txt", $newlist);
        file_put_contents("data/$chat_id/ali.txt", "No");
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
خب ایدی $textmassage از بلاکی درآمد 😎",
]);
#===============================================================================
}
elseif($textmassage == "امار📊" && $from_id = $ADMIN){
$user = file_get_contents("Member.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
bot('Sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
تعداد کاربران 📋: 10$member_count

آماردهی پیشرفته ⚙️
👤 تعداد کاربران ربات : $member_count
🔰 تعداد مدیران ربات : 1
◼️ تعداد بلاکی های ربات : 1",
]);
#===============================================================================
}
elseif($textmassage == "فوروارد همگانی🔊" && $from_id == $ADMIN){
    file_put_contents("data/$from_id/ali.txt","fwr");
 bot('Sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" 🔹 پیام خود را در قالب متن ارسال نمایید :",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"پنل"]
],
]
])
]);
#-------------------------------------------------------------------------------
}
elseif($ali == "fwr" && $from_id == $ADMIN){
    file_put_contents("data/$from_id/ali.txt","none");
bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" پیام همگانی فرستاده شد.",
  ]);
 $all_member = fopen( "Member.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
Forward($user, $chat_id,$message_id);
#-----------------------------------------------------------------------------
}}
//----------------------------------------------------------------------
elseif($textmassage == "تنظیم متن زیرمجموعه ⚡️" && $from_id == $ADMIN){

    file_put_contents("data/$from_id/ali.txt","mtns");

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🎗 متن استارت مورد نظر خود را ارسال نمایید :

متن فعلی : $mtnzir",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
"resize_keyboard"=>true,'one_time_keyboard' => true,
])
]); 
}
elseif($ali == "mtns" && $from_id == $ADMIN){

file_put_contents("data/mtnzir.txt",$textmassage);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"تنظیم شد ✔️

متن جدید : $textmassage",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
"resize_keyboard"=>true,'one_time_keyboard' => true,
])
]);
}
//----------------------------------------------------------------------
elseif($textmassage == "تنظیم متن استارت ⚡️" && $from_id == $ADMIN){

    file_put_contents("data/$from_id/ali.txt","mtns");

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🎗 متن استارت مورد نظر خود را ارسال نمایید :

متن فعلی : $mtnstart",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
"resize_keyboard"=>true,'one_time_keyboard' => true,
])
]); 
}
elseif($ali == "mtns" && $from_id == $ADMIN){

file_put_contents("data/mtnstart.txt",$textmassage);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"تنظیم شد ✔️

متن جدید : $textmassage",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
"resize_keyboard"=>true,'one_time_keyboard' => true,
])
]);
}
#=======================================================================================================================================================================================================================================
elseif ($textmassage == "خاموش کردن ربات🚫" && $from_id == $ADMIN) {
file_put_contents("bot.txt","false");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات با موفقیت خاموش شد ✔️",
]);
 
}
elseif ($textmassage == "روشن کردن ربات♨️" && $from_id == $ADMIN) {
file_put_contents("bot.txt","true");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ربات با موفقیت روشن شد ✔️",
]);
#===============================================================================
}
}
unlink("error_log");
?>