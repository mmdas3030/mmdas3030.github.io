<?php
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'],
['lower' => '91.108.4.0', 'upper' => '91.108.7.255'],
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
include("jdf.php");
date_default_timezone_set('Asia/Tehran');

/* 
جایی خزش نکنی یه وقت 💔
*/
//=================[✔️]===================\\
define('API_KEY','[*[TOKEN]*]');//توکن ربات
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function deleteFolder($path){
if(is_dir($path) === true){
$files = array_diff(scandir($path), array('.', '..'));
foreach ($files as $file)
deleteFolder(realpath($path) . '/' . $file);
return rmdir($path);
}else if (is_file($path) === true)
return unlink($path);
return false;
} 
function sendmessage($chat_id, $text, $pars_mde){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>$pars_mde
 ]);
 }
function senddocument($chat_id, $document, $caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption
 ]);
 }
function sendphoto($chat_id, $photo, $captionl){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
function sendvideo($chat_id, $video, $caption){
 bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>$video,
 'caption'=>$caption
 ]);
 }
function sendvoice($chat_id, $voice, $caption){
 bot('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>$voice,
 'caption'=>$caption
 ]);
 }
function sendaudio($chat_id, $audio, $caption, $title ,$performer){
 bot('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>$audio,
 'caption'=>$caption,
 'title'=>$title,
 'performer'=>$performer
 ]);
 }
function Forward($KojaShe,$AzKoja,$KodomMSG){
 bot('ForwardMessage',[
 'chat_id'=>$KojaShe,
 'from_chat_id'=>$AzKoja,
 'message_id'=>$KodomMSG
 ]);
 }
 
 $data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$textt = $update->callback_query->message->text;
$inline = $update->inline_query->query;
$inline_message_id = $update->callback_query->inline_message_id;
$step= file_get_contents("data/$from_id/file.txt");
$update = json_decode(file_get_contents('php://input'));
$text = $update->message->text;
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$message = $update->message;
$from_id = $message->from->id;
$name = $message->from->frst_name;
$username = $message->from->username;
$lastname = $message->from->last_name;
$first_name = $message->from->first_name;
$botsorce = $update->message->reply_to_message->forward_from->id;
$type = $update->message->chat->type;
$textha = file_get_contents("text");
$senam = file_get_contents("data/$from_id/setnam.txt");
mkdir("data/$from_id");
mkdir("data");
mkdir("text/$senam");
$setr = file_get_contents("data/$from_id/setnt.txt");
$channel= file_get_contents("channel.txt");
$tch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$channel&user_id=".$from_id))->result->status;
$step = file_get_contents("data/$from_id/step.txt");
$sos= file_get_contents("channel.txt");
$tch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$sos&user_id=".$from_id))->result->status;
$step = file_get_contents("data/$from_id/step.txt");
$bot = "@[*[USERNAME]*]";  //ایدی بات با
$botn = "[*[USERNAME]*]";//ایدی بات بدون @
$name_bot = "اختاپوس";
$sos = "[*[CHANNEL]*]"; //ایدی پشتیبان
$admin = [*[ADMIN]*];  //عددی ادمین
//=================[✔️]===================\\
$home = json_encode([
'keyboard' => [
[['text' => '💬 آموزش کلمه'],['text' => '➕ افزودن به گروه']],
[['text' => '🧑‍💻 پشتیبانی'],['text' => '🫧 راهنما']],
[['text' => '💫 تاریخ و ساعت']],
], 
'resize_keyboard' =>true,
]);
 //=================[✔️]===================\\
 if(file_exists("channel.txt")){
 if($tch != 'member'  &&  $tch != 'creator' && $tch != 'administrator' ){
 bot('sendmessage',[
'chat_id'=>$from_id,
'text'=>" 
جهت حمایت از ما لطفاً در کانال های زیر عضو شوید
و سپس [ /start ] را بزنید
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🔐 • | عضویت در کانال | • 🔐",'url'=>"t.me/$sos"]],
],
])
]);
exit();
} }
/* 
جایی خزش نکنی یه وقت 💔
*/
if(strpos($text,"'") !== false or strpos($text,'"') !== false or strpos($text,"}") !== false or strpos($text,"{") !== false or 
strpos($text,"Token") !== false or
strpos($text,'getme') !== false or strpos($text,"GetMe") !== false or strpos($text,"kajserver") !== false or strpos($text,"update") !== false or strpos($text,"UPDATE") !== false or strpos($text,"Update") !== false or strpos($text,"https://api") !== false or strpos($text,"zip") !== false or strpos($text,"ZIP") !== false or strpos($text,"Zip") !== false or strpos($text,"ZipArchive") !== false or strpos($text,"ZiP") !== false or strpos($text,"_GET") !== false or strpos($text,"php://input") !== false or strpos($text,"eval") !== false or strpos($text,"Done!") !== false or strpos($text,"curl_exec") !== false or strpos($text,"avid") !== false or strpos($text,"]") !== false or strpos($text,"[") !== false or strpos($text,";") !== false or strpos($text,"*") !== false or strpos($text,"&") !== false or strpos($text,"^") !== false or  strpos($text,",") !== false){ 
  bot('sendmessage',[
 'chat_id'=>$chat_id,
  'text'=>" پیام شما حاوی موارد مشکوک میباشد🛑⁦O_o⁩
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
  bot('sendmessage',[
 'chat_id'=>$admin,
 'text'=>"این کاربر تبلیغ کرد⛔ 
👤پروفایلش

📍 آیدی عددیش : $from_id
📍یوزرنیم : @$usernamee
📍 تبلیغش🔻
$text",
  ]); 
 }
//=================[✔️]===================\\
/* 
اوپن شده در ✔️ 🌀
🔱 @$sos
dark_loading
❗اوپن کردن بدون منبع پیگرد ناموسی دارد !
*/
if(strpos($text,"/start") !== false && $type != "supergroup"){
$user = file_get_contents('Members.txt');
$members = explode("\n",$user);
if (!in_array($chat_id,$members)){
$add_user = file_get_contents('Members.txt');
$add_user .= $chat_id."\n";
file_put_contents('Members.txt',$add_user);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
👋 سلام $first_name
عزیز من ربات اختاپوس هستم از دکمه های زیر استفاده نمایید
",
'reply_markup'=>$home,
]);
}else{
$o = file_get_contents("text/$text/text.txt");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$o",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown"
]);
}
/* 
اوپن شده در ✔️ 🌀
🔱 @$sos
$sos: @$sos
❗اوپن کردن بدون منبع پیگرد ناموسی دارد !
*/
if( $type == "supergroup" && $text == "/start"){
	$gro = file_get_contents('grop');
	$userg = file_get_contents('MembersGrop.txt');
$membersg = explode("\n",$userg);
if (!in_array($chat_id,$membersg)){
$add_userg = file_get_contents('MembersGrop.txt');
$add_userg .= $chat_id."\n";
file_put_contents('MembersGrop.txt',$add_userg);
	
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
👋 سلام
😎 من اختاپوس هستم میتونی با دکمه زیر منو به گروهت ببری 
✅ برای دریافت راهنما کافیه عبارت
 🫧 راهنما
رو توی گروه ارسال کنی
",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>"💞 افزودن $name_bot به گروه 💞",'url'=>"https://t.me/$botn?startgroup=new"]], 
  ] ])
]);
}}
if( $type == "supergroup" && $text == "/start$bot"){
	$gro = file_get_contents('grop');
	$userg = file_get_contents('MembersGrop.txt');
$membersg = explode("\n",$userg);
if (!in_array($chat_id,$membersg)){
$add_userg = file_get_contents('MembersGrop.txt');
$add_userg .= $chat_id."\n";
file_put_contents('MembersGrop.txt',$add_userg);
	
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
👋 سلام
😎 من اختاپوس هستم میتونی با دکمه زیر منو به گروهت ببری 
✅ برای دریافت راهنما کافیه عبارت
 🫧 راهنما
رو توی گروه ارسال کنی
",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>"💞 افزودن $name_bot به گروه 💞",'url'=>"https://t.me/$botn?startgroup=new"]],
  ] ])
]);
}}
//=================[✔️]===================\\
if($text == '🔙' ){
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"💫 به منو اصلی برگشتیم.",
'reply_markup'=>$home,
]);
file_put_contents("data/$from_id/step.txt","none");
exit;
}
if(preg_match('/^(bego|echo|بگو) (.*)/s', $text, $mtch)){
$mamad = strtoupper("$mtch[2]");
	bot('deletemessage',[
        'chat_id'=>$chat_id,
        'message_id'=>$message_id,
        ]);
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$mamad",
]);
	} 
	/* 
جایی خزش نکنی یه وقت 💔
*/
//=================[✔️]===================\\
if($text == "💬 آموزش کلمه"){
file_put_contents("data/$from_id/step.txt","setname");
file_put_contents("data/$from_id/setnt.txt"," ");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"چیو میخوای یاد بدی 🙂",
'parse_mode'=>"html",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard' => [
[['text' => '🔙']],
], 
'resize_keyboard' => true
])
]);
}
/* 
*/
//==//
elseif($text == "➕ افزودن به گروه"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"‌👈 برای افزودن اختاپوس به گروه خود بر روی دکمه شیشه ایی زیر  کلیک کنید.",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'inline_keyboard'=>[
[['text'=>"➕ افزودن به گروه",'url'=>"https://telegram.me/$botn?startgroup=addfree"]],  
]])]);}
//==//
elseif($step == "setname"){
@mkdir("text/$text");
file_put_contents("data/$from_id/setnt.txt","$text");
file_put_contents("data/$from_id/step.txt","settext");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"جواب کلمه $text رو چی بدم ؟🧐",
'parse_mode'=>"html",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard' => [
[['text' => '🔙']],
], 
'resize_keyboard' => true
])
]);
}
elseif($step == "settext"){
file_put_contents("text/$setr/text.txt","$text");
file_put_contents("data/$from_id/step.txt","none");
$qad = file_get_contents("data/$from_id/setnt.txt");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"خب اینم یاد گرفتم 🙂📝",
'parse_mode'=>"html",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>$home,
]);
bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"
🆕 کاربر : [$first_name](tg://user?id=$from_id) 

✏️ کلمه ( $qad ) را با جواب ( $text ) به ربات افزود

 ❌ اگر کلمه نامناسبی است این عبارت را از پنل مدیریت حذف کنید. ", 
'parse_mode'=>"MarkDown",
]);
}
//=================[✔️]===================\\
/* 
جایی خزش نکنی یه وقت 💔
*/
if($text == "fal" or $text == "فال"){
$add = "http://www.beytoote.com/images/Hafez/".rand(1,149).".gif";
bot('sendphoto', [
'chat_id' => $chat_id,
'photo'=>$add,
'caption' =>"📜 فال شما ارسال شد!",
'reply_to_message_id'=>$message_id,
]); 
}
if(preg_match('/^(font|Font|فونت) (.*)/s', $text, $mtch)){
$matn = strtoupper("$mtch[2]");
$Eng = ['Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M'];
$Font_0 = ['𝐐','𝐖','𝐄','𝐑','𝐓','𝐘','𝐔','𝐈','𝐎','𝐏','𝐀','𝐒','𝐃','𝐅','𝐆','𝐇','𝐉','𝐊','𝐋','𝐙','𝐗','𝐂','𝐕','𝐁','𝐍','𝐌'];
$Font_1 = ['𝑸','𝑾','𝑬','𝑹','𝑻','𝒀','𝑼','𝑰','𝑶','𝑷','𝑨','𝑺','𝑫','𝑭','𝑮','𝑯','𝑱','𝑲','𝑳','𝒁','𝑿','𝑪','𝑽','𝑩','𝑵','𝑴'];
$Font_2 = ['𝑄','𝑊','𝐸','𝑅','𝑇','𝑌','𝑈','𝐼','𝑂','𝑃','𝐴','𝑆','𝐷','𝐹','𝐺','𝐻','𝐽','𝐾','𝐿','𝑍','𝑋','𝐶','𝑉','𝐵','𝑁','𝑀'];
$Font_3 = ['𝗤','𝗪','𝗘','𝗥','??','𝗬','𝗨','𝗜','𝗢','𝗣','𝗔','𝗦','𝗗','𝗙','𝗚','𝗛','𝗝','𝗞','𝗟','𝗭','𝗫','𝗖','𝗩','𝗕','𝗡','𝗠'];
$Font_4 = ['𝖰','𝖶','𝖤','𝖱','𝖳','𝖸','𝖴','𝖨','𝖮','𝖯','𝖠','𝖲','𝖣','𝖥','𝖦','𝖧','𝖩','𝖪','𝖫','??','𝖷','𝖢','𝖵','𝖡','𝖭','𝖬'];
$Font_5 = ['𝕼','𝖂','𝕰','𝕽','𝕵','𝚼','𝖀','𝕿','𝕺','𝕻','𝕬','𝕾','𝕯','𝕱','𝕲','𝕳','𝕴','𝕶','𝕷','𝖅','𝖃','𝕮','𝖁','𝕭','𝕹','𝕸'];
$Font_6 = ['𝔔','𝔚','𝔈','ℜ','𝔍','ϒ','𝔘','𝔗','𝔒','𝔓','𝔄','𝔖','𝔇','𝔉','𝔊','ℌ','ℑ','𝔎','𝔏','ℨ','𝔛','ℭ','𝔙','𝔅','𝔑','𝔐'];
$Font_7 = ['𝙌','𝙒','𝙀','𝙍','𝙏','𝙔','𝙐','𝙄','𝙊','𝙋','𝘼','𝙎','𝘿','𝙁','𝙂','𝙃','𝙅','𝙆','𝙇','𝙕','𝙓','𝘾','𝙑','𝘽','𝙉','𝙈'];
$Font_8 = ['𝘘','𝘞','𝘌','𝘙','𝘛','𝘠','𝘜','𝘐','𝘖','𝘗','𝘈','𝘚','𝘋','𝘍','𝘎','𝘏','𝘑','𝘒','𝘓','𝘡','𝘟','𝘊','𝘝','𝘉','𝘕','𝘔'];
$Font_9 = ['Q̶̶','W̶̶','E̶̶','R̶̶','T̶̶','Y̶̶','U̶̶','I̶̶','O̶̶','P̶̶','A̶̶','S̶̶','D̶̶','F̶̶','G̶̶','H̶̶','J̶̶','K̶̶','L̶̶','Z̶̶','X̶̶','C̶̶','V̶̶','B̶̶','N̶̶','M̶̶'];
$Font_10 = ['Q̷̷̶̶','W̷̷̶̶','E̷̷̶̶','R̷̷̶̶','T̷̷̶̶','Y̷̷̶̶','U̷̷̶̶','I̷̷̶̶','O̷̷̶̶','P̷̷̶̶','A̷̷̶̶','S̷̷̶̶','D̷̷̶̶','F̷̷̶̶','G̷̷̶̶','H̷̷̶̶','J̷̷̶̶','K̷̷̶̶','L̷̷̶̶','Z̷̷̶̶','X̷̷̶̶','C̷̷̶̶','V̷̷̶̶','B̷̷̶̶','N̷̷̶̶','M̷̷̶̶'];
$Font_11 = ['Q͟͟','W͟͟','E͟͟','R͟͟','T͟͟','Y͟͟','U͟͟','I͟͟','O͟͟','P͟͟','A͟͟','S͟͟','D͟͟','F͟͟','G͟͟','H͟͟','J͟͟','K͟͟','L͟͟','Z͟͟','X͟͟','C͟͟','V͟͟','B͟͟','N͟͟','M͟͟'];
$Font_12 = ['Q͇͇','W͇͇','E͇͇','R͇͇','T͇͇','Y͇͇','U͇͇','I͇͇','O͇͇','P͇͇','A͇͇','S͇͇','D͇͇','F͇͇','G͇͇','H͇͇','J͇͇','K͇͇','L͇͇','Z͇͇','X͇͇','C͇͇','V͇͇','B͇͇','N͇͇','M͇͇'];
$Font_13 = ['Q̤̤','W̤̤','E̤̤','R̤̤','T̤̤','Y̤̤','Ṳ̤','I̤̤','O̤̤','P̤̤','A̤̤','S̤̤','D̤̤','F̤̤','G̤̤','H̤̤','J̤̤','K̤̤','L̤̤','Z̤̤','X̤̤','C̤̤','V̤̤','B̤̤','N̤̤','M̤̤'];
$Font_14 = ['Q̰̰','W̰̰','Ḛ̰','R̰̰','T̰̰','Y̰̰','Ṵ̰','Ḭ̰','O̰̰','P̰̰','A̰̰','S̰̰','D̰̰','F̰̰','G̰̰','H̰̰','J̰̰','K̰̰','L̰̰','Z̰̰','X̰̰','C̰̰','V̰̰','B̰̰','N̰̰','M̰̰'];
$Font_15 = ['디','山','乇','尺','亇','丫','凵','工','口','ㄗ','闩','丂','刀','下','彑','⼶','亅','片','乚','乙','乂','亡','ム','乃','力','从'];
$Font_16= ['ዓ','ሠ','ይ','ዩ','ፐ','ሃ','ሀ','ፗ','ዐ','የ','ል','ና','ሏ','ፑ','ፘ','ዘ','ጋ','ኸ','ረ','ጓ','ጰ','ር','ህ','ፎ','በ','ጠ'];
$Font_17= ['Ꭷ','Ꮃ','Ꭼ','Ꮢ','Ꭲ','Ꭹ','Ꮜ','Ꮖ','Ꮻ','Ꮲ','Ꭺ','Ꮪ','Ꭰ','Ꮀ','Ꮐ','Ꮋ','Ꭻ','Ꮶ','Ꮮ','Ꮓ','Ꮱ','Ꮯ','Ꮩ','Ᏼ','N','Ꮇ'];
$Font_18= ['Ǫ','Ѡ','Σ','Ʀ','Ϯ','Ƴ','Ʋ','Ϊ','Ѳ','Ƥ','Ѧ','Ƽ','Δ','Ӻ','Ǥ','ⴼ','Ɉ','Ҟ','Ɫ','Ⱬ','Ӽ','Ҁ','Ѵ','Ɓ','Ɲ','ᛖ'];
$Font_19= ['ꐎ','ꅐ','ꂅ','ꉸ','ꉢ','ꌦ','ꏵ','ꀤ','ꏿ','ꉣ','ꁲ','ꌗ','ꅓ','ꊰ','ꁅ','ꍬ','ꀭ','ꂪ','꒒','ꏣ','ꉧ','ꊐ','ꏝ','ꃃ','ꊮ','ꂵ'];
$Font_20= ['ᘯ','ᗯ','ᕮ','ᖇ','ᙢ','ᖻ','ᑌ','ᖗ','ᗝ','ᑭ','ᗩ','ᔕ','ᗪ','ᖴ','ᘜ','ᕼ','ᒍ','ᖉ','ᒐ','ᘔ','᙭','ᑕ','ᕓ','ᗷ','ᘉ','ᗰ'];
$Font_21= ['ᑫ','ᗯ','ᗴ','ᖇ','Ꭲ','Ꭹ','ᑌ','Ꮖ','ᝪ','ᑭ','ᗩ','ᔑ','ᗞ','ᖴ','Ꮐ','ᕼ','ᒍ','Ꮶ','Ꮮ','Ꮓ','᙭','ᑕ','ᐯ','ᗷ','ᑎ','ᗰ'];
$Font_22= ['ℚ','Ꮤ','℮','ℜ','Ƭ','Ꮍ','Ʋ','Ꮠ','Ꮎ','⅌','Ꭿ','Ꮥ','ⅅ','ℱ','Ꮹ','ℋ','ℐ','Ӄ','ℒ','ℤ','ℵ','ℭ','Ꮙ','Ᏸ','ℕ','ℳ'];
$Font_23= ['Ԛ','ᚠ','ᛊ','ᚱ','ᛠ','ᚴ','ᛘ','ᛨ','θ','ᚹ','ᚣ','ᛢ','ᚦ','ᚫ','ᛩ','ᚻ','ᛇ','ᛕ','ᚳ','Z','ᚷ','ᛈ','ᛉ','ᛒ','ᚺ','ᚥ'];
$Font_24= ['𝓠','𝓦','𝓔','𝓡','𝓣','𝓨','𝓤','𝓘','𝓞','𝓟','𝓐','𝓢','𝓓','𝓕','𝓖','𝓗','𝓙','𝓚','𝓛','𝓩','𝓧','𝓒','𝓥','𝓑','𝓝','𝓜'];
$Font_25= ['𝒬','𝒲','ℰ','ℛ','𝒯','𝒴','𝒰','ℐ','𝒪','𝒫','𝒜','𝒮','𝒟','ℱ','𝒢','ℋ','𝒥','𝒦','ℒ','𝒵','𝒳','𝒞','𝒱','ℬ','𝒩','ℳ'];$Font_26= ['ℚ','𝕎','𝔼','ℝ','𝕋','𝕐','𝕌','𝕀','𝕆','ℙ','𝔸','𝕊','𝔻','𝔽','𝔾','ℍ','𝕁','𝕂','𝕃','ℤ','𝕏','ℂ','𝕍','𝔹','ℕ','𝕄'];
$Font_27= ['Ｑ','Ｗ','Ｅ','Ｒ','Ｔ','Ｙ','Ｕ','Ｉ','Ｏ','Ｐ','Ａ','Ｓ','Ｄ','Ｆ','Ｇ','Ｈ','Ｊ','Ｋ','Ｌ','Ｚ','Ｘ','Ｃ','Ｖ','Ｂ','Ｎ','Ｍ'];
$Font_28= ['ǫ','ᴡ','ᴇ','ʀ','ᴛ','ʏ','ᴜ','ɪ','ᴏ','ᴘ','ᴀ','s','ᴅ','ғ','ɢ','ʜ','ᴊ','ᴋ','ʟ','ᴢ','x','ᴄ','ᴠ','ʙ','ɴ','ᴍ'];
$Font_29= ['𝚀','𝚆','𝙴','𝚁','𝚃','𝚈','𝚄','𝙸','𝙾','𝙿','𝙰','𝚂','𝙳','𝙵','𝙶','𝙷','𝙹','𝙺','𝙻','𝚉','𝚇','𝙲','𝚅','𝙱','𝙽','𝙼'];
$Font_30= ['ᵟ','ᵂ','ᴱ','ᴿ','ᵀ','ᵞ','ᵁ','ᴵ','ᴼ','ᴾ','ᴬ','ˢ','ᴰ','ᶠ','ᴳ','ᴴ','ᴶ','ᴷ','ᴸ','ᶻ','ˣ','ᶜ','ⱽ','ᴮ','ᴺ','ᴹ'];
$Font_31= ['Ⓠ','Ⓦ','Ⓔ','Ⓡ','Ⓣ','Ⓨ','Ⓤ','Ⓘ','Ⓞ','Ⓟ','Ⓐ','Ⓢ','Ⓓ','Ⓕ','Ⓖ','Ⓗ','Ⓙ','Ⓚ','Ⓛ','Ⓩ','Ⓧ','Ⓒ','Ⓥ','Ⓑ','Ⓝ','Ⓜ'];
$Font_32= ['🅀','🅆','🄴','🅁','🅃','🅈','🅄','🄸','🄾','🄿','🄰','🅂','🄳','🄵','🄶','🄷','🄹','🄺','🄻','🅉','🅇','🄲','🅅','🄱','🄽','🄼'];
$Font_33= ['🅠','🅦','🅔','🅡','🅣','🅨','🅤','🅘','🅞','🅟','🅐','🅢','🅓','🅕','🅖','🅗','🅙','🅚','🅛','🅩​','🅧','🅒','🅥','🅑','🅝','🅜'];
$Font_34= ['🆀','🆆','🅴','🆁','🆃','🆈','🆄','🅸','🅾','🅿','🅰','🆂','🅳','🅵','🅶','🅷','🅹','🅺','🅻','🆉','🆇','🅲','🆅','🅱','🅽','🅼'];
$Font_35= ['🇶 ','🇼 ','🇪 ','🇷 ','🇹 ','🇾 ','🇺 ','🇮 ','🇴 ','🇵 ','🇦 ','🇸 ','🇩 ','🇫 ','🇬 ','🇭 ','🇯 ','🇰 ','🇱 ','🇿 ','🇽 ','🇨 ','🇻 ','🇧 ','🇳 ','🇲 '];
$nn = str_replace($Eng,$Font_0,$matn);
$a = str_replace($Eng,$Font_1,$matn);
$b = str_replace($Eng,$Font_2,$matn);
$c = trim(str_replace($Eng,$Font_3,$matn));
$d = str_replace($Eng,$Font_4,$matn);
$e = str_replace($Eng,$Font_5,$matn);
$f = str_replace($Eng,$Font_6,$matn);
$g = str_replace($Eng,$Font_7,$matn);
$h = str_replace($Eng,$Font_8,$matn);
$i = str_replace($Eng,$Font_9,$matn);
$j = str_replace($Eng,$Font_10,$matn);
$k = str_replace($Eng,$Font_11,$matn);
$l = str_replace($Eng,$Font_12,$matn);
$m = str_replace($Eng,$Font_13,$matn);
$n = str_replace($Eng,$Font_14,$matn);
$o = str_replace($Eng,$Font_15,$matn);
$p= str_replace($Eng,$Font_16,$matn);
$q= str_replace($Eng,$Font_17,$matn);
$r= str_replace($Eng,$Font_18,$matn);
$s= str_replace($Eng,$Font_19,$matn);
$t= str_replace($Eng,$Font_20,$matn);
$u= str_replace($Eng,$Font_21,$matn);
$v= str_replace($Eng,$Font_22,$matn);
$w= str_replace($Eng,$Font_23,$matn);
$x= str_replace($Eng,$Font_24,$matn);
$y= str_replace($Eng,$Font_25,$matn);
$z= str_replace($Eng,$Font_26,$matn);
$aa= str_replace($Eng,$Font_27,$matn);
$ac= str_replace($Eng,$Font_28,$matn);
$ad= str_replace($Eng,$Font_29,$matn);
$af= str_replace($Eng,$Font_30,$matn);
$ag= str_replace($Eng,$Font_31,$matn);
$ah= str_replace($Eng,$Font_32,$matn);
$am= str_replace($Eng,$Font_33,$matn);
$as= str_replace($Eng,$Font_34,$matn);
$pol= str_replace($Eng,$Font_35,$matn);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text' => "
1 - $nn
2 - $a
3 - $b
4 - $c
5 - $d
6 - $e
7 - $f
8 - $g
9 - $h
10 - $i
11 - $j
12 - $k
13 - $l
14 - $m
15 - $n
16 - $o
17 - $p
18 - $q
19 - $r
20 - $s
21 - $t
22 - $u
23 - $v
24 - $w
25 - $x
26 - $y
27 - $z
28 - $aa
29 - $ac
30 - $ad
31 - $af
32 - $ag
33 - $ah
34 - $am
35 - $as
36 - $pol

فونت شما آماده شد : $mtch[2] ♥

دقت کنید که فقط از متن های انگلیسی یا لاتین میتوانید استفاده کنید ." ,
'parse_mode'=>'MarkDown',
'reply_to_message_id'=>$message_id,
]);
}
/* 
جایی خزش نکنی یه وقت 💔
*/

if($text == "🧑‍💻 پشتیبانی"){
file_put_contents("data/$from_id/step.txt","setname");
file_put_contents("data/$from_id/setnt.txt"," ");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🤍 دوست گرامی جهت ارتباط با پشتیبانی روی لینک زیر کلیک کنید.
 🏖️  @$sos
",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard' => [
[['text' => '🔙']],
], 
'resize_keyboard' => true
])
]);
}
/* 
جایی خزش نکنی یه وقت 💔
*/
//=================[✔️]===================\\
$backad = json_encode([
'keyboard'=>[
[['text'=>"/panel"]],
],
"resize_keyboard"=>true,
]);
$panel = json_encode([
'keyboard'=>[
[['text'=>"📍 آمار ربات"]],
[['text'=>"📍 فوروارد به همه"],['text'=>"📍 پیام به همه"]],
[['text'=>"📍 حذف کلمه"]],
[['text'=>"🔙"]],
],
"resize_keyboard"=>true,
]);
if($text == '/panel'  && $from_id == $admin){
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♥️ به پنل خوش امدید",
'reply_markup'=>$panel,
]);
file_put_contents("data/$from_id/step.txt","none");
exit;
}
if($text == "/panel" && $from_id == $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♥️ به پنل خوش امدید",
 'parse_mode'=>"markdown",
  'reply_markup'=>$panel,
]);
}
if($text == "📍 تنظیم جوین اجبار" && $from_id == $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📨 لطفا آدرس کانال رو بدون @ ارسال کنید",
 'parse_mode'=>"markdown",
  'reply_markup'=>$backad,
]);
file_put_contents("data/$from_id/step.txt","jo");
}
elseif($step == "jo" && $from_id == $admin){
file_put_contents("data/$chat_id/step.txt","none");
file_put_contents("channel.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>" ✅ کانال @$text تنظیم شد.
ربات حتما ادمین کانال باشد !
",
'parse_mode' => 'html',
  'reply_markup'=>$panel,
]);
}
if($text == "📍 حذف کلمه" && $from_id == $admin){
	file_put_contents("data/$from_id/step.txt","delk");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❇️مدیر گرامی متن مورد نظر را ارسال کنید",
 'parse_mode'=>"markdown",
  'reply_markup'=>$backad,
]);
}
/* 
جایی خزش نکنی یه وقت 💔
*/
if($step == "delk" && $from_id == $admin){
		bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت حذف شد ✅",
 'parse_mode'=>"markdown",
  'reply_markup'=>$panel,
]);
		deletefolder("text/$text"); 
	file_put_contents("data/$from_id/step.txt","none");
}

if($text ==   '📍 آمار ربات' && $from_id == $admin){
$users = file_get_contents("Members.txt");
$member_id = explode("\n",$users);
$member_count = count($member_id) -1;

$users1 = file_get_contents("MembersGrop.txt");
$member_id1 = explode("\n",$users1);
$gropha = count($member_id1) -1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
〽️آمار اعضای ربات اختاپوس : $member_count 
🔷 تعداد گروه ها از این آمار : $gropha
",
 'parse_mode'=>"markdown",
 ]);
}
if($text == '📍 پیام به همه' && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","Send");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "پیامتون رو بفرستید تا به همه گروه ها و کاربرانی که ربات مورد استفاده انهاست بفرستم",
'parse_mode'=>'html',
'reply_markup'=>$backad,
]);
}
if($text == '/creator' or $text == "سازنده"){
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "@$sos سازنده ربات ",
'parse_mode'=>'html',
]);
}
elseif($step == "Send" && $from_id == $admin){
file_put_contents("data/$chat_id/step.txt","none");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>" پیام همگانی فرستاده شد.",
'parse_mode' => 'html',
  'reply_markup'=>$panel,
]);
$all_member = fopen( "Members.txt", "r");
while( !feof( $all_member)) {
$user = fgets( $all_member);
SendMessage($user,$text,'html');
}
}
/* 
جایی خزش نکنی یه وقت 💔
*/
if($text == '📍 فوروارد به همه' && $from_id == $admin){
file_put_contents("data/$from_id/step.txt","forvar");
bot('sendMessage',[
'chat_id' => $chat_id,
'text' => "پیامتونو رو فروارد کنید تا به تمامی کاربران و گروه ها ارسال شود",
'parse_mode'=>'html',
'reply_markup'=>$backad,
]);
}
elseif($step == "forvar" && $from_id == $admin){
file_put_contents("data/$chat_id/step.txt","none");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📬فرواد به همه ارسال شد به تمامی کاربران و گروه ها",
'parse_mode' => 'html',
  'reply_markup'=>$panel,
]);
$forp = fopen( "Members.txt", 'r'); 
while( !feof( $forp)) { 
$fakar = fgets( $forp); 
Forward($fakar, $chat_id,$message_id); 
  } 
  /* 
جایی خزش نکنی یه وقت 💔
*/
   bot('sendMessage',[ 
   'chat_id'=>$chat_id, 
   'text'=>"با موفقیت فروارد شد.", 
   ]);
}
/* 
جایی خزش نکنی یه وقت 💔
*/
 elseif(strpos($text,'خوبی' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"خوبم تو خوبی", 
"🚶🏻 مرسی ", 
"🤨نه تو خوبی؟", 
"🙁به تو چه که خوبم یا ن",
"اره تو چی",
"😟باز تویی؟",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'بای' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"خدافظ", 
"برو دیگه برنگرد", 
"👋",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'گوه' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"گوه", 
"فاعک  ", 
"🤨", 
"برای خودت",
"گونی",
"😐",
"😤",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}

elseif(strpos($text,'سلام' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"سلام چخبر😊", 
"باز چی میخوای😕؟",
"سلام خوبی🧐",
"😟باز تویی؟",
"سلام🗿",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
elseif(strpos($text,'چطوری' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"خوبم تو خوبی😀", 
"مرسی❤️ ", 
"به تو چه🤨", 
"به تو چه که چطوریم🙁 ",
"میگذره",
"باز تویی😟؟",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}    
elseif(strpos($text,'عشق' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"عاشقتم", 
"🚶🏻 عشقمی ", 
"منم عاشقتم", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}  
elseif(strpos($text,'اصل' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اصل بدم؟", 
"به تو چه🗿", 
"پشمک 100 پشمک اباد", 
"اصل نمیدم🙁 ؟ ",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}   
elseif(strpos($text,'😂' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"به چی میخندی", 
"اوسکل 😂😐 ",
"رو  اب بخندی😒", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}     
        
elseif(strpos($text,'پیوی' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"نمیام😂", 
"پیوی نرو بی ادب😐😒", 
"میخوای مخ بزنی❌ 😂", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
elseif(strpos($text,'😐' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"انقد پوکر نده خودت شبیه پوکر شدی ", 
"چته تو همش داری پوکر میدی نکنه مریضی", 
" نکنه چیزیت شده هی پوکر میدی😂😒",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
                elseif(strpos($text,'کص' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"زشته", 
"خودتی ", 
"بی ادب😐", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
elseif(strpos($text,'👍' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اوکب", 
"اوکی😘 ", 
"حله😄", 
"باشه😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😁' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"قلبتو قربون😘😘 ", 
"حلهرو آب بخندی😃", 
"خوش خنده",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😄' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"بسه دیگه چقدر میخندی😑 ", 
"رو آب بخندی😃", 
"توش باشه بخندی🤣😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'🥰' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چقدر قلبی شدی😂😍", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😇' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"ادای خوب ها رو در نیار😒", 
"فک کردی خیلی خوبی ؟", 
"چقدر دختر خوبی هستی🤣", 
"چقدر پسر خوبی هستی 😂",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'😛' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"زبون درازی نکن😒", 
"زبونشو ببین😐😂 ", 
"زبون تو بکش تو 🤣", 
"موش بخورتت😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'🙃' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"🙂🙃", 
"😎😘", 
"برعکس نشو سرت گیج میره😝", 
"موش بخورتت😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'آره' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اجر پاره", 
"اره اره درست میگه 😂", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😋' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چی خوردی به من ندادی😒", 
"خوش مزه بود؟ ", 
"چی خوردی؟😐", 
"23 ساعت از 24 ساعت در حال خوردن هستی😂🤣",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😝' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"جوووون😉😃", 
"برقراری زبون دراز؟🥺😝", 
"سر کیفی داری زبون درازی میکنی😂", 
"به به 😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😒' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چه تو😒😕", 
"نکنه پولتو ندادم ناراحت میشی😐😒", 
"چپکی نگام نکن😒", 
"بدو بینم باو😏",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😢' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"بیا بغلم قربونت بشم😁", 
"😢",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😜' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"شنگول شدی😂", 
"چی شده امروز شنگول شدی🤣", 
"کلک 😜 چی شده😃", 
"😍❤️",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😗' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"آنقدر بوس می‌کنی حالت بهم نمیخوره؟😂", 
"چقدر بوس می‌کنی تو😐😒", 
"چه خوشگل بوس می‌کنی دم عشقم😘", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'🥲' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اشک شوقه؟😂", 
"ریدممم😂😕", 
"چه خوشگل گریه میکنی😁", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}

 elseif(strpos($text,'حالت' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"قربونت مرسی", 
"عالی😀",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
      
        elseif(strpos($text,'نه' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"نکمه", 
"نه درد ", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}

elseif(strpos($text,'چخبر؟' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"سلامتیت",
"چی بگم",
"هیچی امن و امان",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
           
          
elseif(strpos($text,"لوگو") !== false){
 $text = explode(" ",$text);
 $textn = $text['1'];
bot('sendphoto', [
'chat_id' => $chat_id,
 'photo'=>"https://assets.imgix.net/examples/clouds.jpg?blur=150&w=500&h=500&fit=crop&txt=$textn&txtsize=100&txtclr=ff2e4357&txtalign=middle,center&txtfont=Futura%20Condensed%20Medium&mono=ff6598cc",
 'caption'=>"☝️ لوگوی شما با نام $textn ساخته شد✅",
   'reply_to_message_id'=>$message_id,
 ]);
 
}

elseif(strpos($text,'چخبر' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"سلامتیت",
"چی بگم",
"هیچی امن و امان",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
  elseif(strpos($text,'اختاپوس' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"🫡 باز این اومد",
"😐 برو پی کارت دیگه ", 
"🥸what?", 
"🥸 خب دیگه من رفتم", 
"🫤 بی مزه", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
    
elseif($text == "تاس"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎲',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال انداختن تاس ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(0); 
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "🎲 نتیجه تاس : $value", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
} 
elseif($text == "بازی"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎳',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال انداختن تاس ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(0); 
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => " 🎳  : $value", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
} 
if($text == "💫 تاریخ و ساعت"){
$tarek = file_get_contents("http://api.codebazan.ir/time-date/?td=all");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖⏰➖➖➖➖

$tarek

@$sos
➖➖➖➖➖➖➖➖➖
"]); }

if($text == "/jok"){
$jok = file_get_contents("http://api.codebazan.ir/jok");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"


$jok

@$sos
"]); }

if($text == "/alake"){
$alakimasalan = file_get_contents("http://api.codebazan.ir/jok/alaki-masalan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖💣➖➖➖➖

$alakimasalan

@$sos
➖➖➖➖➖➖➖➖➖
"]); }

if($text == "bio"){
$BioNab = file_get_contents("https://api.codebazan.ir/bio/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📝➖➖➖➖

$BioNab

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "/Danestani"){
$Danestani = file_get_contents("http://api.codebazan.ir/danestani/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🐍➖➖➖➖

$Danestani

@$sos
➖➖➖➖➖➖➖➖➖
"]); }

if($text == "/Khatere"){
$Khatere = file_get_contents("http://api.codebazan.ir/jok/khatere");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🤪➖➖➖➖

$Khatere

@$sos
➖➖➖➖➖➖➖➖➖
"]); }

if($text == "/zekr"){
$zekr = file_get_contents("http://api.codebazan.ir/zekr/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📿➖➖➖➖

$zekr

➖➖➖➖➖➖➖➖➖
"]); }

if($text == "🫧 راهنما"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🔖 بخش راهنمای اختاپوس

🌿 دریافت لوگو با گفتن عبارت زیر
مثال : 
• لوگو اختاپوس (کلمه لوگو + اسم)
➖➖➖➖➖➖➖➖➖➖➖
🎃 بخش سرگرمی :
🎲 • با گفتن عبارت (تاس) ربات بازی تاس ارسال میکند

🤘 • دریافت بیو ناب با گفتن :
 bio

😉 • الکی مثلا با دستور :
/alake

🧐 • دریافت دانستنی با دستور :
/Danestani

😝 • دریافت خاطره کوتاه با دستور :
/Khatere

😂 • دریافت جوک با دستور : 
/jok

🍁 • دریافت فال با گفتن عبارت فال
 ➖➖➖➖➖➖➖➖➖➖➖
🧰 بخش کاربردی
• با گفتن عبارت (💫 تاریخ و ساعت) ربات تاریخ و ساعت را نشان میدهد

📿 • دریافت ذکر امروز با دستور 
/zekr
➖➖➖➖➖➖➖➖➖➖➖
✏️ با گفتن عبارت font + متن انگلیسی فونت دلخواه شما را میسازد
❕ مثلا:
🔖 (font Okhtapos)
➖➖➖➖➖➖➖➖➖➖➖
🔖 در بخش اموزش کلمه به اختاپوس میتوانید به او کلمه یاد دهید
➖➖➖➖➖➖➖➖➖➖➖
☑️ در بخش افزودن اختاپوس به گروه میتوانید ربات را به گروه خود اضافه کنید

💫 کانال ما :
@$sos
",
]);
}
unlink("error_log");  
?>