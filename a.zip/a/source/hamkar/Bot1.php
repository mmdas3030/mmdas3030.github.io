<?php
/*
🥲 سورس ربات همکاره

😕❤️ اسکی میری منبع بزن 

🧑‍💻نویسنده : @PHPOR

🥷 چنل اوپن کننده : @NwesoursTm
*/

ob_start();
define('API_KEY','[*[TOKEN]*]');
function bot($method,$datas=[]){
    $url = 'https://api.telegram.org/bot'.API_KEY.'/'.$method;
$ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//-----------------variable-----------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$Dev = [*[ADMIN]*];
$channel = "[*[CHANNEL]*]";
$step1 = file_get_contents("data/$from_id/step1.txt");
$step = file_get_contents("data/$from_id/step.txt");
$message_id = $message->message_id;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
//-----------------تنطیمات------------------- 
$startBot = "سلام به ربات همه کاره خوش آمدید ❤️";
$help = "✅ این ربات کاملا رایگان میباشد و هرگونه کلاه برداری به ما مربوط نمیشود 

🤖 تنها ایدی معتبر ربات ما 《 @[*[USERNAME]*] 》میباشد 

🌵 و تنها کانال معتبر تیم ما 《 @[*[CHANNEL]*] 》میباشد"; 
$Creator = "🤖 سازنده ربات 
🎖: @[*[CHANNEL]*]";
//------------------start-------------------
if($text == '/start'){
$user = file_get_contents('MMBER.txt');
$members = explode("\n",$user);
if (!in_array($chat_id,$members)){
$add_user = file_get_contents('MMBER.txt');
$add_user .= $chat_id."\n";
file_put_contents('MMBER.txt',$add_user);
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$startBot",'parse_mode' => "HTML",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text' => '▫️یاد دادن کلمه به اختاپوس▫️'],['text' => '🏆افزودن اختاپوس به گروه🏆']],
[['text' => 'پشتیبانی💬'],['text' => 'راهنما⁉️']],
[['text' => '😎کانالمون']],
[['text' => '💖 اسپانسر'],['text' => 'بزودی ...']],
], 
'resize_keyboard'=>false,
  'selective' => false,
  ])
]);
}
//-------------------Back1--------------------
elseif($text == "🔙 بازگشت"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به منوی اصلی خوش آمدید 🌹",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🎮 پنل بازی"]],
[['text'=>"⚙ پنل کاربردی"],['text'=>"🧸 پنل سرگرمی"]],
[['text'=>"🤖 سازنده"],['text'=>"⁉️ راهنما"]], 
[['text'=>"📢 کانال ما"]],
],
'resize_keyboard'=>true,
])
]);
}
//-------------------سرگرمی--------------------
elseif($text == "🧸 پنل سرگرمی"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش سرگرمی خوش امدید از منوی زیر انتخاب کنید 👇",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ذکر روز 🕌"]],
[['text'=>"داستان کوتاه 📒"],['text'=>"دیالوگ ماندگار 💘"]],
[['text'=>"الکی مثلا 🙄"],['text'=>"دانستنی 🤔"]],
[['text'=>"جوک 😂"],['text'=>"بیوگرافی ❤️‍🔥"]],
[['text'=>"🌵 ساخت توکن"],['text'=>"خاطره 📝"]], 
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}

//-------------------Back2--------------------
elseif($text == "🔙"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به منو پنل کاربردی خوش آمدید 😊",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"چیستان 😃"],['text'=>"فشح 😜"]],
[['text'=>"تاریخ و ساعت ⏰"],['text'=>"حدیث 📿"]],
[['text'=>"سمبل متن 💫"],['text'=>"تلویزیون آنلاین 📺"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//-------------------کاربردی-------------------
elseif($text == "⚙ پنل کاربردی"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش کاربردی خوش امدید از منوی زیر انتخاب کنید 👇",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"چیستان 😃"],['text'=>"فشح 😜"]],
[['text'=>"تاریخ و ساعت ⏰"],['text'=>"حدیث 📿"]],
[['text'=>"سمبل متن 💫"],['text'=>"تلویزیون آنلاین 📺"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//-----------------بازی-------------------
elseif($text == "🎮 پنل بازی"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش بازی ها خوش امدید از منوی زیر انتخاب کنید 👇",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"بخش 2⃣"],['text'=>"بخش 1⃣"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//------------------بخش 1--------------------
elseif($text == "بخش 1⃣"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش بازی بخش اول خوش امدید از منوی زیر انتخاب کنید 👇",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"⚡ رعد"],['text'=>"🔥 آتش"]],
[['text'=>"😂 خنده"],['text'=>"🦾 قدرت"]],
[['text'=>"💸 پول"],['text'=>"💎 الماس"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//-------------------سمبل متن--------------------
elseif($text == "سمبل متن 💫"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"نوع سمبل خود را انتخاب کنید 💫",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"ぁ"],['text'=>"ㄵ"]],
[['text'=>"⸙"],['text'=>"⇄"]],
[['text'=>"🔙"]],
],
'resize_keyboard'=>true,
])
]);
}
//-------------------mak--------------------
if($text == '⁉️ راهنما'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$help",'parse_mode' => "HTML",
]);
}
//-------------------channelbot--------------------
if($text == '📢 کانال ما'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"جهت حمایت از ربات و اطلاع رسانی از آپدیت ها و تغییرات غضو کانال ما شوید 🎈

🎊 : @$channel",'parse_mode' => "HTML",
]);
}
//-------------------⸙⸙⸙⸙⸙⸙--------------------
if($text == '⸙'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"«  »  ༺  ༻  ༼  ༽
⳹  ⳼  ⳺  ⳻  ⸔  ⸕
⋋  ⋌  ⁌  ⁍  э  є
ʕ  ʔ  ୨  ୧  ᓀ  ᓂ
￫  ￩  ₍  ₎  ☜  ☞
¿  ?  ┐  ┌  └  ┘
⸶  ⸷  ֎  ֍  ࿙  ࿚
ॐ  Ѻ  ๏  ↀ  ↂ  ↈ
߷  Ⱅ  Ⱚ  Ⰿ  Ⰶ  ⵥ
ⵌ  ⵋ  〠  ⸙  ⸎  ┤  ├
⸸  ෴  ༈  ༐  ࿈
࿇  ࿅  ༕  ࿂  ྿  ࿉
࿄  ፨  ፠  ᨖ  ۩  ۞
᪣  ᪥  ᯼  ᯽  ᯾  ᳀
᳁  ᳂  ᳃  ᴥ  ※  †
༒  ‡  ⁛  ⁑  ʬ  §
©  ®  ℗",'parse_mode' => "HTML",
]);
}
//-------------------⇄⇄⇄⇄--------------------
if($text == '⇄'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"↕  ↔  ↓  →  ↑  ←
↛  ↚  ↙  ↘  ↗  ↖
↡  ↠  ↟  ↞  ↝  ↜
↧  ↤  ↥  ↤  ↣  ↢
↭  ↬  ↫  ↪  ↩  ↨
↳  ↲  ↱  ↰  ↯  ↮
↹  ↸  ↷  ↶  ↵  ↴
↿  ↾  ↽  ↼  ↻  ↺
⇅  ⇄  ⇃  ⇂  ⇁  ⇀
⇋  ⇊  ⇉  ⇈  ⇇  ⇆
⇑  ⇐  ⇏  ⇎  ⇍  ⇌
⇗  ⇖  ⇕  ⇔  ⇓  ⇒
⇝  ⇜  ⇛  ⇚  ⇙  ⇘
⇣  ⇢  ⇡  ⇠  ⇟  ⇞
⇩  ⇨  ⇧  ⇦  ⇥  ⇤
⇯  ⇮  ⇭  ⇬  ⇫  ⇪
⇵  ⇴  ⇳  ⇲
⇱  ⇰
⇻  ⇺  ⇹  ⇸  ⇷  ⇶
∁  ∀  ⇿  ⇾  ⇽  ⇼
∇  ∆  ∅  ∄  ∃  ∂
∍  ∌  ∋  ∊  ∉  ∈
∓  −  ∑  ∐  ∏  ∎
∙  ∘  ∗  ∖  ∕  ∔
∟  ∞  ∝  ∜  ∛  √
∥  ∤  ∣  ∢  ∡  ∠
∫  ∪  ∩  ∨  ∧  ∦
∱  ∰  ∯  ∮  ∭  ∬
∷  ∶  ∵  ∴  ∳  ∲
∽  ∼  ∻  ∺  ∹  ∸
≃  ≂  ≁  ≀  ∿  ∾
≉  ≈  ≇  ≆  ≅  ≄
≏  ≎  ≍  ≌  ≋  ≊
≕  ≔  ≓  ≒  ≑  ≐
≛  ≚
⎇  ⎆  ⎅  ⎄  ⎃  ⎂
⎍  ⎌  ⎋  ⎊  ⎉  ⎈
⎓  ⎒  ⎑  ⎐  ⎏  ⎎
⎙  ⎘  ⎗  ⎖  ⎕  ⎔
⎟  ⎞  ⎝  ⎜  ⎛  ⎚
⎥  ⎤  ⎣  ⎢  ⎡  ⎠
⎫  ⎪  ⎩  ⎨  ⎧  ⎦
⎱  ⎰  ⎯  ⎮  ⎭  ⎬
⎷  ⎶  ⎵  ⎴  ⎳  ⎲
⎽  ⎼  ⎻  ⎺  ⎹  ⎸
⏃  ⏂  ⏁  ⏀  ⎿  ⎾
⏉  ⏈  ⏇  ⏆  ⏅  ⏄
⏏  ⏎  ⏍  ⏌  ⏋  ⏊
⏕  ⏔  ⏓  ⏒  ⏑  ⏐
⏛  ⏚  ⏙  ⏘  ⏗  ⏖
⏡  ⏠  ⏟  ⏞  ⏝  ⏜
⏧  ⏦  ⏥  ⏤
⌟  ⌞  ⌝  ⌜
⌧  ⌦  ⌥  ⌤  ⌣  ⌢
⌭  ⌬  ⌫  〉  〈  ⌨
⌳  ⌲  ⌱  ⌰  ⌯  ⌮
⌹  ⌸  ⌷  ⌶  ⌵  ⌴
⌿  ⌾  ⌽  ⌼  ⌻  ⌺
⍅  ⍄  ⍃  ⍂  ⍁  ⍀
⍋  ⍊  ⍉  ⍈  ⍇  ⍆
⍑  ⍐  ⍏  ⍎  ⍍  ⍌
⍗  ⍖  ⍕  ⍔  ⍓  ⍒
⍝  ⍜  ⍛  ⍚  ⍙  ⍘
⍣  ⍢  ⍡  ⍠  ⍟  ⍞
⍩  ⍨  ⍧  ⍦  ⍥  ⍤
⍯  ⍮  ⍭  ⍬  ⍫  ⍪
⍵  ⍴  ⍳  ⍲  ⍱  ⍰
⍻  ⍺  ⍹  ⍸  ⍷  ⍶
⎁  ⎀  ⍿  ⍾  ⍽  ⍼",'parse_mode' => "HTML",
]);
}
//-------------------ㄵㄵㄵㄵ--------------------
if($text == 'ㄵ'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ㄱ   ㄲ   ㄳ   ㄴ   ㄵ   ㄶ   ㄷ   ㄸ   ㄹ   ㄺ   ㄻ   ㄼ   ㄽ   ㄾ   ㄿ   ㅀ   ㅁ   ㅂ   ㅃ   ㅄ   ㅅ   ㅆ   ㅇ   ㅈ   ㅉ   ㅊ   ㅋ   ㅌ   ㅍ   ㅎ   ㅏ   ㅐ   ㅑ   ㅒ   ㅓ   ㅔ   ㅕ   ㅖ   ㅗ   ㅘ   ㅙ   ㅚ   ㅛ   ㅜ   ㅝ   ㅞ   ㅟ   ㅠ   ㅡ   ㅢ   ㅥ   ㅦ   ㅧ   ㅨ   ㅩ   ㅪ   ㅫ   ㅬ   ㅭ   ㅮ   ㅯ   ㅰ   ㅱ   ㅲ   ㅳ   ㅴ   ㅵ   ㅶ   ㅷ   ㅸ   ㅹ   ㅺ   ㅻ   ㅼ   ㅽ   ㅾ   ㅿ   ㆀ   ㆁ   ㆂ   ㆃ   ㆄ   ㆅ   ㆆ   ㆇ   ㆈ   ㆉ   ㆊ",'parse_mode' => "HTML",
]);
}
//-------------------ぁぁぁぁぁ--------------------
if($text == 'ぁ'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ぁ   あ   ぃ   い   ぅ   う   ぇ   え   ぉ   お   か   が   き   ぎ   く   ぐ   け   げ   こ   ご   さ   ざ   し   じ   す   ず   せ   ぜ   そ   ぞ   た   だ   ち   ぢ   っ   つ   づ   て   で   と   ど   な   に   ぬ   ね   の   は   ば   ぱ   ひ   び   ぴ   ふ   ぶ   ぷ   へ   べ   ぺ   ほ   ぼ   ぽ   ま   み   む   め   も   ゃ   や   ゅ   ゆ   ょ   よ   ら   り   る   れ   ろ   ゎ   わ   ゐ   ゑ   を   ん   ゔ   ゕ   ゖ   ゚   ゛   ゜   ゝ   ゞ   ゟ   ゠   ァ   ア   ィ   イ   ゥ   ウ   ェ
エ   ォ   オ   カ   ガ   キ   ギ   ク   グ   ケ   ゲ   コ   ゴ   サ   ザ   シ   ジ   ス   ズ   セ   ゼ   ソ   ゾ   タ   ダ   チ   ヂ   ッ   ツ   ヅ   テ   デ   ト   ド   ナ   ニ   ヌ   ネ   ノ   ハ   バ   パ   ヒ   ビ   ピ   フ   ブ   プ   ヘ   ベ   ペ   ホ   ボ   ポ   マ   ミ   ム   メ   モ   ャ   ヤ   ュ   ユ   ョ   ヨ   ラ   リ   ル   レ   ロ   ヮ   ワ   ヰ   ヱ   ヲ   ン   ヴ   ヵ   ヶ   ヷ   ヸ   ヹ   ヺ   ・   ー   ヽ   ヾ   ヿ   ㍐   ㍿",'parse_mode' => "HTML",
]);
}
//-------------------Creatorbot--------------------
if($text == '🤖 سازنده'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$Creator",'parse_mode' => "HTML",
]);
}
//-------------------ma1--------------------
if($text == "بخش 2⃣"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
🎮 لیست بازی های  List of games 🎮
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"MotoFX 2 🎠",'url'=>'https://www.gamee.com/game/motofx2'],['text'=>"Little Plane ⛺️",'url'=>'https://www.gamee.com/game/5IsYwla']],
[['text'=>"1+2=3 💡",'url'=>'https://www.gamee.com/game/KQsrLTZp'],['text'=>"Karate Kido 🪙",'url'=>'https://www.gamee.com/game/karatekid2']],
[['text'=>"Beach Racer 💎",'url'=>'https://www.gamee.com/game/fnoschiaJx'],['text'=>"Gravity Ninja🥷",'url'=>'https://www.gamee.com/game/G1oy49taR']],
[['text'=>"Ten 2 One 🧜",'url'=>'https://www.gamee.com/game/ten2one'],['text'=>"Paintball Pandas🐼",'url'=>'https://www.gamee.com/game/pandas']],
[['text'=>"Qubo🎄",'url'=>'https://www.gamee.com/game/u0yXP5o'],['text'=>"Geometry Run 3D🏎",'url'=>'https://www.gamee.com/game/geometryrun']],
] 
]) 
]); 
}
//-------------------رعد--------------------
if($text == '⚡ رعد'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"⚡",'parse_mode' => "HTML",
]);
}
//-------------------آتش--------------------
if($text == '🔥 آتش'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🔥",'parse_mode' => "HTML",
]);
}
//-------------------الماس--------------------
if($text == '💎 الماس'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"💎",'parse_mode' => "HTML",
]);
}
//-------------------خنده--------------------
if($text == '😂 خنده'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😂",'parse_mode' => "HTML",
]);
}
//-------------------قدرت--------------------
if($text == '🦾 قدرت'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🦾",'parse_mode' => "HTML",
]);
}
//-------------------پول--------------------
if($text == '💸 پول'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"💸",'parse_mode' => "HTML",
]);
}
//-------------------tokensaz--------------------
if($text == "🌵 ساخت توکن"){
$passwordSaz = file_get_contents("http://api.codebazan.ir/password/?length=12");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🌵 توکن شما ساخته شد : $passwordSaz
"]); }
//-------------------alakimasalan--------------------
if($text == "الکی مثلا 🙄"){
$alakimasalan = file_get_contents("http://api.codebazan.ir/jok/alaki-masalan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$alakimasalan
"]); }
//-------------------Bio--------------------
if($text == "بیوگرافی ❤️‍🔥"){
$BioNab = file_get_contents("https://api.codebazan.ir/bio/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$BioNab
"]); }
//-------------------onteh--------------------
if($text == "تلویزیون آنلاین 📺"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
پخش آنلاین شبکه های تلویزیونی ایران 👇
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"شبکه یک",'url'=>'http://www.telewebion.com/#!/live/tv1'],['text'=>"شبکه دو",'url'=>'http://www.telewebion.com/#!/live/tv2 ']],
[['text'=>"شبکه سه",'url'=>'http://www.telewebion.com/#!/live/tv3'],['text'=>"شبکه چهار",'url'=>'http://www.telewebion.com/#!/live/tv4']],
[['text'=>"شبکه آموزش",'url'=>'http://www.telewebion.com/#!/live/amouzesh'],['text'=>"شبکه قرآن",'url'=>'http://www.telewebion.com/#!/live/quran']],
[['text'=>"شبکه سلامت",'url'=>'http://www.telewebion.com/#!/live/salamat'],['text'=>"شبکه نسیم",'url'=>'http://www.telewebion.com/#!/live/nasim']],
[['text'=>"شبکه مستند",'url'=>'http://www.telewebion.com/#!/live/mostanad'],['text'=>"شبکه افق",'url'=>'http://www.telewebion.com/#!/live/ofogh']],
[['text'=>"شبکه نمایش",'url'=>'http://www.telewebion.com/#!/live/namayesh'],['text'=>"شبکه آی فیلم",'url'=>'http://www.telewebion.com/#!/live/ifilm']],
[['text'=>"شبکه تهران",'url'=>'http://www.telewebion.com/#!/live/tehran ']],
] 
]) 
]); 
}
//-------------------Danestani--------------------
if($text == "دانستنی 🤔"){
$Danestani = file_get_contents("http://api.codebazan.ir/danestani/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$Danestani
"]); }
//-------------------dialogue--------------------
if($text == "دیالوگ ماندگار 💘"){
$dialogue = file_get_contents("http://api.codebazan.ir/dialog/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$dialogue
"]); }
//-------------------dastan--------------------
if($text == "داستان کوتاه 📒"){
$dastan = file_get_contents("http://api.codebazan.ir/dastan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$dastan
"]); }
//-------------------zekr--------------------
if($text == "ذکر روز 🕌"){
$zekr = file_get_contents("http://api.codebazan.ir/zekr/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$zekr
"]); }
//-------------------proxy--------------------
if($text == "چیستان 😃"){
$proxy = file_get_contents("http://api.codebazan.ir/danestani/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$proxy
"]); }
//-------------------fosh--------------------
if($text == "فشح 😜"){
$fosh = file_get_contents("https://XDTM.IR/Api/fosh.php");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$fosh
"]); }
//-------------------hadis--------------------
if($text == "حدیث 📿"){
$hadis = file_get_contents("http://api.codebazan.ir/hadis/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$hadis
"]); }
//-------------------tarek--------------------
if($text == "تاریخ و ساعت ⏰"){
$tarek = file_get_contents("http://api.codebazan.ir/time-date/?td=all");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$tarek
"]); }
//-------------------footbl--------------------
if($text == "سه تیم بالای جدول لیگ ⚽️"){
$footbl = file_get_contents("http://mrblack.farahost.site/panel/football.php");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$footbl
"]); }
//-------------------jok--------------------
if($text == "جوک 😂"){
$jok = file_get_contents("http://api.codebazan.ir/jok");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$jok
"]); }
//-------------------beu--------------------
if($text == "بیوگرافی ❤️‍🔥بایوزدطدسدطدیدسدیددییدسیمسمیطمثمسمشمشسمسمینسیاممودتتوخککک"){
$BioNab = file_get_contents("https://api.codebazan.ir/bio/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$BioNab
"]); }
//-------------------ater--------------------
if($text == "خاطره 📝"){
$Khatere = file_get_contents("http://api.codebazan.ir/jok/khatere");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$Khatere
"]); }
//-------------------panel--------------------
elseif($text == "/panel"){
bot('sendMessage',[
'chat_id'=>$Dev,
'text'=>"به پنل مدیریت خوش امدید",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"📊 آمار"]],
[['text'=>"🔙 بازگشت"]], 
],
'resize_keyboard'=>true,
])
]);
}
elseif ($text == "📊 آمار"){
$user = file_get_contents("MMBER.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
bot('sendMessage',[
'chat_id' => $Dev,
'text' => "تعداد اعضای ربات : $member_count",
'parse_mode' => 'HTML'
]);
}
elseif($text == "ساعت"){
	$time = date("H:i");
            $fonts = [["𝟶", "𝟷", "𝟸", "??", "𝟺", "𝟻", "𝟼", "𝟽", "𝟾", "??​"],
             ["??", "𝟭", "𝟮", "𝟯", "𝟰", "𝟱", "𝟲", "𝟳", "𝟴", "𝟵"]];
            $time = date("H:i");
            $time2 = str_replace(range(0, 9), $fonts[array_rand($fonts)], date("H:i:s"));
            $day_number = jdate('j');
            $month_number = jdate('n');
            $year_number = jdate('y');
            $day_name = jdate('l');
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"  
⌛ ساعت  $time2  
☀️امروز $day_name  
⚫@DARK_LOADING⚫ سازنده ",
 'parse_mode'=>'html',
 'reply_to_message_id'=>$message_id,
 ]);
 }
 elseif(strpos($text,'خوبی' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"خوبم تو خوبی", 
"🚶🏻 مرسی ", 
"🤨نه تو خوبی؟", 
"🙁به تو چه که خوبم یا ن",
"اره تو چی",
"😟باز تویی؟",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'گوه' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"گوه", 
"فاعک  ", 
"🤨", 
"برای خودت",
"گونی",
"😐",
"😤",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}

elseif(strpos($text,'سلام' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"سلام چخبر😊", 
"باز چی میخوای😕؟",
"سلام خوبی🧐",
"😟باز تویی؟",
"سلام🗿",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
elseif(strpos($text,'چطوری' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"خوبم تو خوبی😀", 
"مرسی❤️ ", 
"به تو چه🤨", 
"به تو چه که چطوریم🙁 ",
"میگذره",
"باز تویی😟؟",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}    
elseif(strpos($text,'عشق' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"عاشقتم", 
"🚶🏻 عشقمی ", 
"منم عاشقتم", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}  
elseif(strpos($text,'اصل' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اصل بدم؟", 
"به تو چه🗿", 
"پشمک 100 پشمک اباد", 
"اصل نمیدم🙁 ؟ ",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}   
elseif(strpos($text,'😂' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"به چی میخندی", 
"اوسکل 😂😐 ",
"رو  اب بخندی😒", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}     
        
elseif(strpos($text,'پیوی' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"نمیام😂", 
"پیوی نرو بی ادب😐😒", 
"میخوای مخ بزنی❌ 😂", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
elseif(strpos($text,'😐' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"انقد پوکر نده خودت شبیه پوکر شدی ", 
"چته تو همش داری پوکر میدی نکنه مریضی", 
" نکنه چیزیت شده هی پوکر میدی😂😒",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
                elseif(strpos($text,'کص' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"زشته", 
"خودتی ", 
"بی ادب😐", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
elseif(strpos($text,'👍' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اوکب", 
"اوکی😘 ", 
"حله😄", 
"باشه😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😁' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"قلبتو قربون😘😘 ", 
"حلهرو آب بخندی😃", 
"خوش خنده",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😄' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"بسه دیگه چقدر میخندی😑 ", 
"رو آب بخندی😃", 
"توش باشه بخندی🤣😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'🥰' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چقدر قلبی شدی😂😍", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😇' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"ادای خوب ها رو در نیار😒", 
"فک کردی خیلی خوبی ؟", 
"چقدر دختر خوبی هستی🤣", 
"چقدر پسر خوبی هستی 😂",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'😛' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"زبون درازی نکن😒", 
"زبونشو ببین😐😂 ", 
"زبون تو بکش تو 🤣", 
"موش بخورتت😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'🙃' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"🙂🙃", 
"😎😘", 
"برعکس نشو سرت گیج میره😝", 
"موش بخورتت😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
        elseif(strpos($text,'آره' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اجر پاره", 
"اره اره درست میگه 😂", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😋' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چی خوردی به من ندادی😒", 
"خوش مزه بود؟ ", 
"چی خوردی؟😐", 
"23 ساعت از 24 ساعت در حال خوردن هستی😂🤣",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😝' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"جوووون😉😃", 
"برقراری زبون دراز؟🥺😝", 
"سر کیفی داری زبون درازی میکنی😂", 
"به به 😁",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😒' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چه تو😒😕", 
"نکنه پولتو ندادم ناراحت میشی😐😒", 
"چپکی نگام نکن😒", 
"بدو بینم باو😏",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😢' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"بیا بغلم قربونت بشم😁", 
"😢",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😜' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"شنگول شدی😂", 
"چی شده امروز شنگول شدی🤣", 
"کلک 😜 چی شده😃", 
"😍❤️",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'😗' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"آنقدر بوس می‌کنی حالت بهم نمیخوره؟😂", 
"چقدر بوس می‌کنی تو😐😒", 
"چه خوشگل بوس می‌کنی دم عشقم😘", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        elseif(strpos($text,'🥲' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"اشک شوقه؟😂", 
"ریدممم😂😕", 
"چه خوشگل گریه میکنی😁", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}

 elseif(strpos($text,'حالت' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"قربونت مرسی", 
"عالی😀",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
      
        elseif(strpos($text,'نه' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"نکمه", 
"نه درد ", 
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}

elseif(strpos($text,'چخبر؟' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"سلامتیت",
"چی بگم",
"هیچی امن و امان",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
           
          
elseif(strpos($text,"لوگو") !== false){
 $text = explode(" ",$text);
 $textn = $text['1'];
bot('sendphoto', [
'chat_id' => $chat_id,
 'photo'=>"https://assets.imgix.net/examples/clouds.jpg?blur=150&w=500&h=500&fit=crop&txt=$textn&txtsize=100&txtclr=ff2e4357&txtalign=middle,center&txtfont=Futura%20Condensed%20Medium&mono=ff6598cc",
 'caption'=>"☝️ لوگوی شما با نام $textn ساخته شد✅",
   'reply_to_message_id'=>$message_id,
 ]);
 
}

elseif(strpos($text,'چخبر' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"سلامتیت",
"چی بگم",
"هیچی امن و امان",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"[$randslm](tg://user?id=$from_id)",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}
        
  elseif(strpos($text,'الپریمو' ) !== false or strpos($text,'golabi' ) !== false){
$slm = [
"چیه😑",
"ها😑",
"بگو😑",
"شول تایم",
];
$randslm = $slm[array_rand($slm)];

         bot('sendMessage',[
            'chat_id'=>$chat_id, 
            'text'=>"[$randslm]",
            'reply_to_message_id'=>$update->message->message_id,'parse_mode'=>'Markdown', 
        ]);}  
   
//-------------------end--------------------
?>