<?php
# Channel : @LiwixSource -- | Channel : @LiwixSource -- #
# -- کرون جاب 1 دقیقه ای -- #
$dominname= $_SERVER['SERVER_NAME'];
	$kojasfile=$_SERVER['PHP_SELF'];
	$kofile=str_replace("send.php",'',$kojasfile);
$koga="http://$dominname$kofile";
$remmlocked=file_get_contents("data/lockremm.txt");
$channel=file_get_contents("Dade/coj.txt");
$channel=str_replace("@",null, $channel);
if($remmlocked=="✅"){
$las=file_get_contents("Dade/lastm.txt");
$tedad=file_get_contents("data/mizanremm.txt");
$html=file_get_contents("https://t.me/$channel");

function Get_m(){
    global $html;
preg_match('#<div class="tgme_page_extra">(.*?) members</div>#',$html,$match);
    return $match[1];
}
$m=Get_m();
$m =str_replace(" ",null, $m);
if($m != null){
if($las-$m>=$tedad){
    $mwarn=file_get_contents("$koga/index.php?what=mwarn");
echo "$mwarn";
}
file_put_contents("Dade/lastm.txt",$m);

echo "Checked -!";
}
else{
echo "Error -!";
}
}
echo $koga;

# Channel : @LiwixSource -- | Channel : @LiwixSource -- #
?>