<?php
define('API_KEY','[*[TOKEN]*]');
function Bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
if($_GET['step'] == 'sendtoall')
{
	$type = $_GET['type'];
	$scan = json_decode(file_get_contents("data/settings.json"),true)['members'];
	foreach($scan as $username){
		$user = str_replace('.json',null,$username);
		if($type == 'text'){
			Bot('sendmessage',['chat_id'=>$user,'text'=>$_GET['text']]);
		}
		elseif($type == 'photo'){
			Bot('sendphoto',['chat_id'=>$user,'photo'=>$_GET["msgid"],'caption'=>$_GET["text"]]);
		}
		elseif($type == 'file'){
			Bot('sendDocument',['chat_id'=>$user,'document'=>$_GET["msgid"],'caption'=>$_GET["text"]]);
		}
		elseif($type == 'video'){
			Bot('SendVideo',['chat_id'=>$user,'video'=>$_GET["msgid"],'caption'=>$_GET["text"]]);
		}
		elseif($type == 'music'){
			Bot('SendAudio',['chat_id'=>$user,'audio'=>$_GET["msgid"],'caption'=>$_GET["text"]]);
		}
		elseif($type == 'sticker'){
			Bot('SendSticker',['chat_id'=>$user,'sticker'=>$_GET["msgid"],'caption'=>$_GET["text"]]);
		}
		elseif($type == 'voice'){
			Bot('SendVoice',['chat_id'=>$user,'voice'=>$_GET["msgid"],'caption'=>$_GET["text"]]);
		}
	}
}
?>