<?php
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
ob_start();
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("سیلام گوگاب (:");
//========================================================//
ini_set('error_logs','off');
error_reporting(0);
//========================================================//
define('API_KEY',"[*[TOKEN]*]"); //توکن ربات
function bot($method,$dataPaMicKs=[]){
 $url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$dataPaMicKs);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
//========================================================//
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
bot('editMessagetext',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>$text,
'parse_mode'=>$parse_mode,
'disable_web_page_preview'=>$disable_web_page_preview,
'reply_markup'=>$keyboard
]);
} 
//========================================================//
function Forward($kojashe, $azkoja, $kodommsg){
bot('forwardmessage',[
'chat_id'=>$kojashe,
'from_chat_id'=>$azkoja,
'message_id'=>$kodommsg
]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
function Ziper($folder_to_zip_path, $destination_zip_file_path){
$rootPath = realpath($folder_to_zip_path);
$zip = new ZipArchive();
$zip->open($destination_zip_file_path, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$files = new RecursiveIteratorIterator(
new RecursiveDirectoryIterator($rootPath),
RecursiveIteratorIterator::LEAVES_ONLY);
foreach ($files as $name => $file){
if(!$file->isDir()){
$filePath = $file->getRealPath();
$relativePath = substr($filePath, strlen($rootPath) + 1);
$zip->addFile($filePath, $relativePath);
}
}
$zip->close();
}
//========================================================//
function getMUsage(){
     $mem = memory_get_usage();
     $kb = $mem / 1024;
return substr($kb, 0, -5).' KB';
}
//========================================================//
$update = json_decode(file_get_contents('php://input'));
//========================================================//
$Dev = [*[ADMIN]*]; //ایدی عددی ادمین
$token = "[*[TOKEN]*]"; //توکن ربات
$PaMicKee = "[*[USERNAME]*]"; //ایدی ربات
$sos = "[*[CHANNEL]*]"; //ایدی چنل برای جوین
//========================================================//
$message = $update->message;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
$text = $update->message->text;
$first_name = $update->message->from->first_name;
$last_name = $update->message->from->last_name;
$username = $update->message->from->username;
$dataPaMicK = $update->callback_query->dataPaMicK;
$step = file_get_contents("dataPaMicK/$from_id/step.txt");
@$onof = file_get_contents("dataPaMicK/onof.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=@$sos&user_id=".$from_id));
$tch = $forchaneel->result->status;
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
mkdir("admin");
mkdir("dataPaMicK");
mkdir("dataPaMicK/$from_id");
//========================================================//
if(file_exists("admin/textstarttt.json")){
$textstarttt = file_get_contents("admin/textstarttt.json");
$textstarttt = str_replace('ID',$from_id,$textstarttt);
}else{
$textstarttt = "متن استارت تنظیم نشده است ! 📝";
}
//========================================================//
if(file_exists("admin/textback.json")){
$textback = file_get_contents("admin/textback.json");
$textback = str_replace('ID',$from_id,$textback);
}else{
$textback = "متن برگشت تنظیم نشده است ! 🔙";
}
//========================================================//
if(file_exists("admin/textspanser.json")){
$textspanser = file_get_contents("admin/textspanser.json");
$textspanser = str_replace('ID',$from_id,$textspanser);
}else{
$textspanser = "متن اسپانسر تنظیم نشده است ! 👔";
}
//========================================================//
if(file_exists("admin/textersal.json")){
$textersal = file_get_contents("admin/textersal.json");
$textersal = str_replace('ID',$from_id,$textersal);
}else{
$textersal = "متن ارسال پیام تنظیم نشده است ! 📝";
}
//========================================================//
if(file_exists("admin/textresid.json")){
$textresid = file_get_contents("admin/textresid.json");
$textresid = str_replace('ID',$from_id,$textresid);
}else{
$textresid = "متن رسید پیام تنظیم نشده است ! 🗳";
}
//========================================================//
if($onof == "off" && $from_id != $Dev){
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"
☹️ ربات توسط مدیر خاموش شده است.
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "اطلاع رسانی ربات |🛃|", 'url' => "https://t.me/$sos"]],
]
])
]);
exit();
}
//========================================================//
if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
❌ دوست عزیز برای استفاده از ربات ما باید حتماً در کانال ما عضو باشید. ابتدا عضو کانال زیر شوید

@$sos

بعد از عضویت در کانال بالا /start کنید
",
'parse_mode'=>"HTML",
]);
exit();
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
//========================================================//
if($text == '/start'){
$user = file_get_contents('MMBER.txt');
$members = explode("\n",$user);
if (!in_array($chat_id,$members)){
$add_user = file_get_contents('MMBER.txt');
$add_user .= $chat_id."\n";
file_put_contents('MMBER.txt',$add_user);
}
file_put_contents("dataPaMicK/$chat_id/Pamick.txt", "no");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$textstarttt",'parse_mode' => "HTML",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"👨‍💻 پشتیبانی ربات "]],
[['text'=>"🗃️"],['text'=>"🎮"],['text'=>"🖥️"],['text'=>"🎩"]],
],
'resize_keyboard'=>true,
  'selective' => true,
  ])
]);
}
//========================================================//
elseif($text == "🔙 بازگشت" or $text == "🔙 بازگشت️"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$textback",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"👨‍💻 پشتیبانی ربات "]],
[['text'=>"🗃️"],['text'=>"🎮"],['text'=>"🖥️"],['text'=>"🎩"]],
],
'resize_keyboard'=>true,
])
]);
file_put_contents("dataPaMicK/$from_id/step.txt","none");
}
//========================================================//
elseif($text =="👨‍💻 پشتیبانی ربات"){
file_put_contents("dataPaMicK/$from_id/step.txt","pvresan");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
$textersal
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🔙 بازگشت️"]],
]
])
]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
elseif($step == "pvresan" && $text !="🔙 بازگشت️" && $text != "پیام به کاربر 👤"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$textresid",
]);
bot('sendMessage',[
'chat_id'=>$Dev,
'text'=>"
❤️ مدیر عزیز پیام جدیدی دریافت شد

💬 پیوی فرد :  [$first_name](tg://user?id=$from_id)
🔢 یوزر آیدی : `$from_id`
 (کلیک کنید تا کپی شود)
 
 *🔖 پیام فرد : $text*
 
✅ برای پاسخ دادن به این فرد روی گزینه پیام به کاربر کلیک کنید
",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'پیام به کاربر 👤']],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
file_put_contents("dataPaMicK/$from_id/step.txt","none");
}
//========================================================//
elseif($text == "🗃️"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش کاربردی خوش امدید از منوی زیر انتخاب کنید 👇",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"فونت و سمبل 💫"],['text'=>"تاریخ و ساعت ⏰"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//========================================================//
elseif($text == "🎩"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"$textspanser",
'parse_mode'=>"HTML",  
]);
}
//========================================================//
elseif($text == "🎮"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش سرگرمی خوش امدید از منوی زیر انتخاب کنید 👇",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"بازی ها 🕹"],['text'=>"تلویزیون آنلاین 📺"]],
[['text'=>"ذکر امروز 📿"],['text'=>"حدیث 🕌"],['text'=>"پسورد ساز ⛓️"]],
[['text'=>"جوک 😂"],['text'=>"داستان کوتاه 📒"],['text'=>"الکی مثلا 💣"]],
[['text'=>"بیو ناب🍫"],['text'=>"دانستنی 🐍"],['text'=>"خاطره 🤪"]],
[['text'=>"پَ نَ پَ 😆"],['text'=>"دیالوگ ماندگار 📃"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//========================================================//
elseif($text == "فونت و سمبل 💫"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"👇 نوع symbol را انتخاب کنید",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"فونت اسم ✍"]],
[['text'=>"ぁ"],['text'=>"ㄵ"]],
[['text'=>"⸙"],['text'=>"⇄"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//========================================================//
elseif($text == "فونت اسم ✍"){
	bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
〽️ برای دریافت فونت اسم خود مانند مثال زیر ارسال کنید :
🖌️ حتماً متن ارسالی انگلیسی باشد!
font Name 
",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//========================================================//
if(preg_match('/^(font) (.*)/s', $text, $mtch)){
 $matn = strtoupper("$mtch[2]");
$Eng = ['Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M'];
$Font_0 = ['𝐐','𝐖','𝐄','𝐑','𝐓','𝐘','𝐔','𝐈','𝐎','𝐏','𝐀','𝐒','𝐃','𝐅','𝐆','𝐇','𝐉','𝐊','𝐋','𝐙','𝐗','𝐂','𝐕','𝐁','𝐍','𝐌'];
$Font_1 = ['𝑸','𝑾','𝑬','𝑹','𝑻','𝒀','𝑼','𝑰','𝑶','𝑷','𝑨','𝑺','𝑫','𝑭','𝑮','𝑯','𝑱','𝑲','𝑳','𝒁','𝑿','𝑪','𝑽','𝑩','𝑵','𝑴'];
$Font_2 = ['𝑄','𝑊','𝐸','𝑅','𝑇','𝑌','𝑈','𝐼','𝑂','𝑃','𝐴','𝑆','𝐷','𝐹','𝐺','𝐻','𝐽','𝐾','𝐿','𝑍','𝑋','𝐶','𝑉','𝐵','𝑁','𝑀'];
$Font_3 = ['𝗤','𝗪','𝗘','𝗥','𝗧','𝗬','𝗨','𝗜','𝗢','𝗣','𝗔','𝗦','𝗗','𝗙','𝗚','𝗛','𝗝','𝗞','𝗟','𝗭','𝗫','𝗖','𝗩','𝗕','𝗡','??'];
$Font_4 = ['𝖰','𝖶','𝖤','𝖱','𝖳','𝖸','𝖴','𝖨','𝖮','𝖯','𝖠','𝖲','𝖣','𝖥','𝖦','𝖧','𝖩','𝖪','𝖫','𝖹','𝖷','𝖢','𝖵','𝖡','𝖭','𝖬'];
$Font_5 = ['𝕼','𝖂','𝕰','𝕽','𝕵','??','𝖀','𝕿','𝕺','𝕻','𝕬','𝕾','𝕯','𝕱','𝕲','𝕳','𝕴','𝕶','𝕷','𝖅','𝖃','𝕮','𝖁','𝕭','𝕹','𝕸'];
$Font_6 = ['𝔔','𝔚','𝔈','ℜ','𝔍','ϒ','𝔘','𝔗','𝔒','𝔓','𝔄','𝔖','𝔇','𝔉','𝔊','ℌ','ℑ','𝔎','𝔏','ℨ','𝔛','ℭ','𝔙','𝔅','𝔑','𝔐'];
$Font_7 = ['𝙌','𝙒','??','𝙍','𝙏','𝙔','𝙐','𝙄','𝙊','𝙋','𝘼','𝙎','𝘿','𝙁','𝙂','𝙃','𝙅','𝙆','𝙇','𝙕','𝙓','𝘾','𝙑','𝘽','𝙉','𝙈'];
$Font_8 = ['𝘘','𝘞','𝘌','𝘙','𝘛','𝘠','𝘜','𝘐','𝘖','𝘗','𝘈','𝘚','𝘋','𝘍','𝘎','𝘏','𝘑','𝘒','𝘓','𝘡','𝘟','𝘊','𝘝','𝘉','𝘕','𝘔'];
$Font_9 = ['Q̶̶','W̶̶','E̶̶','R̶̶','T̶̶','Y̶̶','U̶̶','I̶̶','O̶̶','P̶̶','A̶̶','S̶̶','D̶̶','F̶̶','G̶̶','H̶̶','J̶̶','K̶̶','L̶̶','Z̶̶','X̶̶','C̶̶','V̶̶','B̶̶','N̶̶','M̶̶'];
$Font_10 = ['Q̷̷','W̷̷','E̷̷','R̷̷','T̷̷','Y̷̷','U̷̷','I̷̷','O̷̷','P̷̷','A̷̷','S̷̷','D̷̷','F̷̷','G̷̷','H̷̷','J̷̷','K̷̷','L̷̷','Z̷̷','X̷̷','C̷̷','V̷̷','B̷̷','N̷̷','M̷̷'];
$Font_11 = ['Q͟͟','W͟͟','E͟͟','R͟͟','T͟͟','Y͟͟','U͟͟','I͟͟','O͟͟','P͟͟','A͟͟','S͟͟','D͟͟','F͟͟','G͟͟','H͟͟','J͟͟','K͟͟','L͟͟','Z͟͟','X͟͟','C͟͟','V͟͟','B͟͟','N͟͟','M͟͟'];
$Font_12 = ['Q͇͇','W͇͇','E͇͇','R͇͇','T͇͇','Y͇͇','U͇͇','I͇͇','O͇͇','P͇͇','A͇͇','S͇͇','D͇͇','F͇͇','G͇͇','H͇͇','J͇͇','K͇͇','L͇͇','Z͇͇','X͇͇','C͇͇','V͇͇','B͇͇','N͇͇','M͇͇'];
$Font_13 = ['Q̤̤','W̤̤','E̤̤','R̤̤','T̤̤','Y̤̤','Ṳ̤','I̤̤','O̤̤','P̤̤','A̤̤','S̤̤','D̤̤','F̤̤','G̤̤','H̤̤','J̤̤','K̤̤','L̤̤','Z̤̤','X̤̤','C̤̤','V̤̤','B̤̤','N̤̤','M̤̤'];
$Font_14 = ['Q̰̰','W̰̰','Ḛ̰','R̰̰','T̰̰','Y̰̰','Ṵ̰','Ḭ̰','O̰̰','P̰̰','A̰̰','S̰̰','D̰̰','F̰̰','G̰̰','H̰̰','J̰̰','K̰̰','L̰̰','Z̰̰','X̰̰','C̰̰','V̰̰','B̰̰','N̰̰','M̰̰'];
$Font_15 = ['디','山','乇','尺','亇','丫','凵','工','口','ㄗ','闩','丂','刀','下','彑','⼶','亅','片','乚','乙','乂','亡','ム','乃','力','从'];
$Font_16= ['ዓ','ሠ','ይ','ዩ','ፐ','ሃ','ሀ','ፗ','ዐ','የ','ል','ና','ሏ','ፑ','ፘ','ዘ','ጋ','ኸ','ረ','ጓ','ጰ','ር','ህ','ፎ','በ','ጠ'];
$Font_17= ['Ꭷ','Ꮃ','Ꭼ','Ꮢ','Ꭲ','Ꭹ','Ꮜ','Ꮖ','Ꮻ','Ꮲ','Ꭺ','Ꮪ','Ꭰ','Ꮀ','Ꮐ','Ꮋ','Ꭻ','Ꮶ','Ꮮ','Ꮓ','Ꮱ','Ꮯ','Ꮩ','Ᏼ','N','Ꮇ'];
$Font_18= ['Ǫ','Ѡ','Σ','Ʀ','Ϯ','Ƴ','Ʋ','Ϊ','Ѳ','Ƥ','Ѧ','Ƽ','Δ','Ӻ','Ǥ','ⴼ','Ɉ','Ҟ','Ɫ','Ⱬ','Ӽ','Ҁ','Ѵ','Ɓ','Ɲ','ᛖ'];
$Font_19= ['ꐎ','ꅐ','ꂅ','ꉸ','ꉢ','ꌦ','ꏵ','ꀤ','ꏿ','ꉣ','ꁲ','ꌗ','ꅓ','ꊰ','ꁅ','ꍬ','ꀭ','ꂪ','꒒','ꏣ','ꉧ','ꊐ','ꏝ','ꃃ','ꊮ','ꂵ'];
$Font_20= ['ᘯ','ᗯ','ᕮ','ᖇ','ᙢ','ᖻ','ᑌ','ᖗ','ᗝ','ᑭ','ᗩ','ᔕ','ᗪ','ᖴ','ᘜ','ᕼ','ᒍ','ᖉ','ᒐ','ᘔ','᙭','ᑕ','ᕓ','ᗷ','ᘉ','ᗰ'];
$Font_21= ['ᑫ','ᗯ','ᗴ','ᖇ','Ꭲ','Ꭹ','ᑌ','Ꮖ','ᝪ','ᑭ','ᗩ','ᔑ','ᗞ','ᖴ','Ꮐ','ᕼ','ᒍ','Ꮶ','Ꮮ','Ꮓ','᙭','ᑕ','ᐯ','ᗷ','ᑎ','ᗰ'];
$Font_22= ['ℚ','Ꮤ','℮','ℜ','Ƭ','Ꮍ','Ʋ','Ꮠ','Ꮎ','⅌','Ꭿ','Ꮥ','ⅅ','ℱ','Ꮹ','ℋ','ℐ','Ӄ','ℒ','ℤ','ℵ','ℭ','Ꮙ','Ᏸ','ℕ','ℳ'];
$Font_23= ['Ԛ','ᚠ','ᛊ','ᚱ','ᛠ','ᚴ','ᛘ','ᛨ','θ','ᚹ','ᚣ','ᛢ','ᚦ','ᚫ','ᛩ','ᚻ','ᛇ','ᛕ','ᚳ','Z','ᚷ','ᛈ','ᛉ','ᛒ','ᚺ','ᚥ'];
$Font_24= ['𝓠','𝓦','𝓔','𝓡','𝓣','𝓨','𝓤','𝓘','𝓞','𝓟','𝓐','𝓢','𝓓','𝓕','𝓖','𝓗','𝓙','𝓚','𝓛','𝓩','𝓧','𝓒','𝓥','𝓑','𝓝','𝓜'];
$Font_25= ['𝒬','𝒲','ℰ','ℛ','𝒯','𝒴','𝒰','ℐ','𝒪','𝒫','𝒜','𝒮','𝒟','ℱ','𝒢','ℋ','𝒥','𝒦','ℒ','𝒵','𝒳','𝒞','𝒱','ℬ','𝒩','ℳ'];
$Font_26= ['ℚ','𝕎','𝔼','ℝ','𝕋','𝕐','𝕌','𝕀','𝕆','ℙ','𝔸','𝕊','𝔻','𝔽','𝔾','ℍ','𝕁','𝕂','𝕃','ℤ','𝕏','ℂ','𝕍','𝔹','ℕ','𝕄'];
$Font_27= ['Ｑ','Ｗ','Ｅ','Ｒ','Ｔ','Ｙ','Ｕ','Ｉ','Ｏ','Ｐ','Ａ','Ｓ','Ｄ','Ｆ','Ｇ','Ｈ','Ｊ','Ｋ','Ｌ','Ｚ','Ｘ','Ｃ','Ｖ','Ｂ','Ｎ','Ｍ'];
$Font_28= ['ǫ','ᴡ','ᴇ','ʀ','ᴛ','ʏ','ᴜ','ɪ','ᴏ','ᴘ','ᴀ','s','ᴅ','ғ','ɢ','ʜ','ᴊ','ᴋ','ʟ','ᴢ','x','ᴄ','ᴠ','ʙ','ɴ','ᴍ'];
$Font_29= ['𝚀','𝚆','𝙴','𝚁','𝚃','??','𝚄','𝙸','𝙾','𝙿','𝙰','𝚂','𝙳','𝙵','𝙶','𝙷','𝙹','𝙺','𝙻','𝚉','𝚇','𝙲','𝚅','𝙱','𝙽','𝙼'];
$Font_30= ['ᵟ','ᵂ','ᴱ','ᴿ','ᵀ','ᵞ','ᵁ','ᴵ','ᴼ','ᴾ','ᴬ','ˢ','ᴰ','ᶠ','ᴳ','ᴴ','ᴶ','ᴷ','ᴸ','ᶻ','ˣ','ᶜ','ⱽ','ᴮ','ᴺ','ᴹ'];
$Font_31= ['Ⓠ','Ⓦ','Ⓔ','Ⓡ','Ⓣ','Ⓨ','Ⓤ','Ⓘ','Ⓞ','Ⓟ','Ⓐ','Ⓢ','Ⓓ','Ⓕ','Ⓖ','Ⓗ','Ⓙ','Ⓚ','Ⓛ','Ⓩ','Ⓧ','Ⓒ','Ⓥ','Ⓑ','Ⓝ','Ⓜ️'];
$Font_32= ['🅀','🅆','🄴','🅁','🅃','🅈','🅄','🄸','🄾','🄿','🄰','🅂','🄳','🄵','🄶','🄷','🄹','🄺','🄻','🅉','??','🄲','🅅','🄱','🄽','🄼'];
$Font_33= ['🅠','🅦','🅔','🅡','🅣','🅨','🅤','🅘','🅞','🅟','🅐','🅢','🅓','🅕','🅖','🅗','🅙','🅚','🅛','🅩 ','🅧','🅒','🅥','🅑','🅝','🅜'];
$Font_34= ['🆀','🆆','🅴','🆁','🆃','🆈','🆄','🅸','🅾️','🅿️','🅰️','🆂','🅳','🅵','🅶','🅷','🅹','🅺','🅻','🆉','🆇','🅲','🆅','🅱️','🅽','🅼'];
$Font_35= ['🇶 ','🇼 ','🇪 ','🇷 ','🇹 ','🇾 ','🇺 ','🇮 ','🇴 ','🇵 ','🇦 ','🇸 ','🇩 ','🇫 ','🇬 ','🇭 ','🇯 ','🇰 ','🇱 ','🇿 ','🇽 ','🇨 ','🇻 ','🇧 ','🇳 ','🇲 '];
//
$nn = str_replace($Eng,$Font_0,$matn);
$a = str_replace($Eng,$Font_1,$matn);
$b = str_replace($Eng,$Font_2,$matn);
$c = trim(str_replace($Eng,$Font_3,$matn));
$d = str_replace($Eng,$Font_4,$matn);
$e = str_replace($Eng,$Font_5,$matn);
$f = str_replace($Eng,$Font_6,$matn);
$g = str_replace($Eng,$Font_7,$matn);
$h = str_replace($Eng,$Font_8,$matn);
$i = str_replace($Eng,$Font_9,$matn);
$j = str_replace($Eng,$Font_10,$matn);
$k = str_replace($Eng,$Font_11,$matn);
$l = str_replace($Eng,$Font_12,$matn);
$m = str_replace($Eng,$Font_13,$matn);
$n = str_replace($Eng,$Font_14,$matn);
$o = str_replace($Eng,$Font_15,$matn);
$p= str_replace($Eng,$Font_16,$matn);
$q= str_replace($Eng,$Font_17,$matn);
$r= str_replace($Eng,$Font_18,$matn);
$s= str_replace($Eng,$Font_19,$matn);
$t= str_replace($Eng,$Font_20,$matn);
$u= str_replace($Eng,$Font_21,$matn);
$v= str_replace($Eng,$Font_22,$matn);
$w= str_replace($Eng,$Font_23,$matn);
$x= str_replace($Eng,$Font_24,$matn);
$y= str_replace($Eng,$Font_25,$matn);
$z= str_replace($Eng,$Font_26,$matn);
$aa= str_replace($Eng,$Font_27,$matn);
$ac= str_replace($Eng,$Font_28,$matn);
$ad= str_replace($Eng,$Font_29,$matn);
$af= str_replace($Eng,$Font_30,$matn);
$ag= str_replace($Eng,$Font_31,$matn);
$ah= str_replace($Eng,$Font_32,$matn);
$am= str_replace($Eng,$Font_33,$matn);
$as= str_replace($Eng,$Font_34,$matn);
$pol= str_replace($Eng,$Font_35,$matn);

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
`$nn`
`$a`
`$b`
`$c`
`$d`
`$e`
`$f`
`$g`
`$h`
`$i`
`$j`
`$k`
`$l`
`$m`
`$n`
`$o`
`$p`
`$q`
`$r`
`$s`
`$t`
`$u`
`$v`
`$w`
`$x`
`$y`
`$z`
`$aa`
`$ac`
`$ad`
`$af`
`$ag`
`$ah`
`$am`
`$as`
`$pol`

فونت شما با اسم $mtch[2] آماده شد کاربر $first_name عزیز😊
",
'parse_mode'=>'MarkDown',  
'reply_markup'=>json_encode([
'keyboard'=>[
    [['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
if($text == 'ㄵ'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ㄱ   ㄲ   ㄳ   ㄴ   ㄵ   ㄶ   ㄷ   ㄸ   ㄹ   ㄺ   ㄻ   ㄼ   ㄽ   ㄾ   ㄿ   ㅀ   ㅁ   ㅂ   ㅃ   ㅄ   ㅅ   ㅆ   ㅇ   ㅈ   ㅉ   ㅊ   ㅋ   ㅌ   ㅍ   ㅎ   ㅏ   ㅐ   ㅑ   ㅒ   ㅓ   ㅔ   ㅕ   ㅖ   ㅗ   ㅘ   ㅙ   ㅚ   ㅛ   ㅜ   ㅝ   ㅞ   ㅟ   ㅠ   ㅡ   ㅢ   ㅥ   ㅦ   ㅧ   ㅨ   ㅩ   ㅪ   ㅫ   ㅬ   ㅭ   ㅮ   ㅯ   ㅰ   ㅱ   ㅲ   ㅳ   ㅴ   ㅵ   ㅶ   ㅷ   ㅸ   ㅹ   ㅺ   ㅻ   ㅼ   ㅽ   ㅾ   ㅿ   ㆀ   ㆁ   ㆂ   ㆃ   ㆄ   ㆅ   ㆆ   ㆇ   ㆈ   ㆉ   ㆊ
@$PaMicKee",'parse_mode' => "HTML",
]);
}
//========================================================//
if($text == 'ぁ'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ぁ   あ   ぃ   い   ぅ   う   ぇ   え   ぉ   お   か   が   き   ぎ   く   ぐ   け   げ   こ   ご   さ   ざ   し   じ   す   ず   せ   ぜ   そ   ぞ   た   だ   ち   ぢ   っ   つ   づ   て   で   と   ど   な   に   ぬ   ね   の   は   ば   ぱ   ひ   び   ぴ   ふ   ぶ   ぷ   へ   べ   ぺ   ほ   ぼ   ぽ   ま   み   む   め   も   ゃ   や   ゅ   ゆ   ょ   よ   ら   り   る   れ   ろ   ゎ   わ   ゐ   ゑ   を   ん   ゔ   ゕ   ゖ   ゚   ゛   ゜   ゝ   ゞ   ゟ   ゠   ァ   ア   ィ   イ   ゥ   ウ   ェ
エ   ォ   オ   カ   ガ   キ   ギ   ク   グ   ケ   ゲ   コ   ゴ   サ   ザ   シ   ジ   ス   ズ   セ   ゼ   ソ   ゾ   タ   ダ   チ   ヂ   ッ   ツ   ヅ   テ   デ   ト   ド   ナ   ニ   ヌ   ネ   ノ   ハ   バ   パ   ヒ   ビ   ピ   フ   ブ   プ   ヘ   ベ   ペ   ホ   ボ   ポ   マ   ミ   ム   メ   モ   ャ   ヤ   ュ   ユ   ョ   ヨ   ラ   リ   ル   レ   ロ   ヮ   ワ   ヰ   ヱ   ヲ   ン   ヴ   ヵ   ヶ   ヷ   ヸ   ヹ   ヺ   ・   ー   ヽ   ヾ   ヿ   ㍐   ㍿
@$PaMicKee",'parse_mode' => "HTML",
]);
}
//========================================================//
if($text == '⸙'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"«  »  ༺  ༻  ༼  ༽
⳹  ⳼  ⳺  ⳻  ⸔  ⸕
⋋  ⋌  ⁌  ⁍  э  є
ʕ  ʔ  ୨  ୧  ᓀ  ᓂ
￫  ￩  ₍  ₎  ☜  ☞
¿  ?  ┐  ┌  └  ┘
⸶  ⸷  ֎  ֍  ࿙  ࿚
ॐ  Ѻ  ๏  ↀ  ↂ  ↈ
߷  Ⱅ  Ⱚ  Ⰿ  Ⰶ  ⵥ
ⵌ  ⵋ  〠  ⸙  ⸎  ┤  ├
⸸  ෴  ༈  ༐  ࿈
࿇  ࿅  ༕  ࿂  ྿  ࿉
࿄  ፨  ፠  ᨖ  ۩  ۞
᪣  ᪥  ᯼  ᯽  ᯾  ᳀
᳁  ᳂  ᳃  ᴥ  ※  †
༒  ‡  ⁛  ⁑  ʬ  §
©  ®  ℗
@$PaMicKee
",'parse_mode' => "HTML",
]);
}
//========================================================//
if($text == '⇄'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"↕  ↔  ↓  →  ↑  ←
↛  ↚  ↙  ↘  ↗  ↖
↡  ↠  ↟  ↞  ↝  ↜
↧  ↤  ↥  ↤  ↣  ↢
↭  ↬  ↫  ↪  ↩  ↨
↳  ↲  ↱  ↰  ↯  ↮
↹  ↸  ↷  ↶  ↵  ↴
↿  ↾  ↽  ↼  ↻  ↺
⇅  ⇄  ⇃  ⇂  ⇁  ⇀
⇋  ⇊  ⇉  ⇈  ⇇  ⇆
⇑  ⇐  ⇏  ⇎  ⇍  ⇌
⇗  ⇖  ⇕  ⇔  ⇓  ⇒
⇝  ⇜  ⇛  ⇚  ⇙  ⇘
⇣  ⇢  ⇡  ⇠  ⇟  ⇞
⇩  ⇨  ⇧  ⇦  ⇥  ⇤
⇯  ⇮  ⇭  ⇬  ⇫  ⇪
⇵  ⇴  ⇳  ⇲
⇱  ⇰
⇻  ⇺  ⇹  ⇸  ⇷  ⇶
∁  ∀  ⇿  ⇾  ⇽  ⇼
∇  ∆  ∅  ∄  ∃  ∂
∍  ∌  ∋  ∊  ∉  ∈
∓  −  ∑  ∐  ∏  ∎
∙  ∘  ∗  ∖  ∕  ∔
∟  ∞  ∝  ∜  ∛  √
∥  ∤  ∣  ∢  ∡  ∠
∫  ∪  ∩  ∨  ∧  ∦
∱  ∰  ∯  ∮  ∭  ∬
∷  ∶  ∵  ∴  ∳  ∲
∽  ∼  ∻  ∺  ∹  ∸
≃  ≂  ≁  ≀  ∿  ∾
≉  ≈  ≇  ≆  ≅  ≄
≏  ≎  ≍  ≌  ≋  ≊
≕  ≔  ≓  ≒  ≑  ≐
≛  ≚
⎇  ⎆  ⎅  ⎄  ⎃  ⎂
⎍  ⎌  ⎋  ⎊  ⎉  ⎈
⎓  ⎒  ⎑  ⎐  ⎏  ⎎
⎙  ⎘  ⎗  ⎖  ⎕  ⎔
⎟  ⎞  ⎝  ⎜  ⎛  ⎚
⎥  ⎤  ⎣  ⎢  ⎡  ⎠
⎫  ⎪  ⎩  ⎨  ⎧  ⎦
⎱  ⎰  ⎯  ⎮  ⎭  ⎬
⎷  ⎶  ⎵  ⎴  ⎳  ⎲
⎽  ⎼  ⎻  ⎺  ⎹  ⎸
⏃  ⏂  ⏁  ⏀  ⎿  ⎾
⏉  ⏈  ⏇  ⏆  ⏅  ⏄
⏏  ⏎  ⏍  ⏌  ⏋  ⏊
⏕  ⏔  ⏓  ⏒  ⏑  ⏐
⏛  ⏚  ⏙  ⏘  ⏗  ⏖
⏡  ⏠  ⏟  ⏞  ⏝  ⏜
⏧  ⏦  ⏥  ⏤
⌟  ⌞  ⌝  ⌜
⌧  ⌦  ⌥  ⌤  ⌣  ⌢
⌭  ⌬  ⌫  〉  〈  ⌨
⌳  ⌲  ⌱  ⌰  ⌯  ⌮
⌹  ⌸  ⌷  ⌶  ⌵  ⌴
⌿  ⌾  ⌽  ⌼  ⌻  ⌺
⍅  ⍄  ⍃  ⍂  ⍁  ⍀
⍋  ⍊  ⍉  ⍈  ⍇  ⍆
⍑  ⍐  ⍏  ⍎  ⍍  ⍌
⍗  ⍖  ⍕  ⍔  ⍓  ⍒
⍝  ⍜  ⍛  ⍚  ⍙  ⍘
⍣  ⍢  ⍡  ⍠  ⍟  ⍞
⍩  ⍨  ⍧  ⍦  ⍥  ⍤
⍯  ⍮  ⍭  ⍬  ⍫  ⍪
⍵  ⍴  ⍳  ⍲  ⍱  ⍰
⍻  ⍺  ⍹  ⍸  ⍷  ⍶
⎁  ⎀  ⍿  ⍾  ⍽  ⍼
@$PaMicKee
",'parse_mode' => "HTML",
]);
}
//========================================================//
elseif($text == "بازی ها 🕹"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"به بخش سرگرمی خوش امدی 😁",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🌐 بازی های آنلاین"]], 
[['text'=>"🎯 دارت بازی کن"],['text'=>"🎲 تاس بنداز"]],
[['text'=>"⚽️ پنالتی بزن"],['text'=>"🏀 بسکتبال بازی کن"]],
[['text'=>"🔙 بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//========================================================//
if($text == "🌐 بازی های آنلاین"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
🎮لیست بازی ها    List of games🎮
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"MotoFX 2 🎠",'url'=>'https://www.gamee.com/game/motofx2'],['text'=>"Little Plane ⛺️",'url'=>'https://www.gamee.com/game/5IsYwla']],
[['text'=>"1+2=3 💡",'url'=>'https://www.gamee.com/game/KQsrLTZp'],['text'=>"Karate Kido 🪙",'url'=>'https://www.gamee.com/game/karatekid2']],
[['text'=>"Beach Racer 💎",'url'=>'https://www.gamee.com/game/fnoschiaJx'],['text'=>"Gravity Ninja🥷",'url'=>'https://www.gamee.com/game/G1oy49taR']],
[['text'=>"Ten 2 One 🧜",'url'=>'https://www.gamee.com/game/ten2one'],['text'=>"Paintball Pandas🐼",'url'=>'https://www.gamee.com/game/pandas']],
[['text'=>"Qubo🎄",'url'=>'https://www.gamee.com/game/u0yXP5o'],['text'=>"Geometry Run 3D🏎",'url'=>'https://www.gamee.com/game/geometryrun']],
] 
]) 
]); 
}
//========================================================//
elseif($text == "🎯 دارت بازی کن"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎯',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال بازی ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]);
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(2.5); 
if($value == 1 or $value == 2 or $value == 3){
$om = "❌ بازیو باختی،امتیاز نگرفتی";
}else{
$om = "🎊 امتیاز بازی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
	
	 elseif($text == "🏀 بسکتبال بازی کن"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🏀',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال بازی ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(7); 
if($value == 1 or $value == 2 or $value == 3){
$om = "❌ بازیو باختی،امتیاز نگرفتی";
}else{
$om = "🎊 امتیاز بازی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
	 elseif($text == "⚽️ پنالتی بزن"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '⚽️',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال پنالتی زدن ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(7); 
if($value == 1 or $value == 2){
$om = "❌ پنالتی باختی،امتیازی نگرفتی";
}else{
$om = "🎊 امتیاز پنالتی : $value";
}
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "$om", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
	
	 elseif($text == "🎲 تاس بنداز"){
$dice = bot('sendDice',[
'chat_id' => $chat_id,
'emoji'=> '🎲',
   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "♻️ در حال انداختن تاس ...", 'callback_data' => "none"]],                       
                    ]
                ]) 
]); 
$value = $dice->result->dice->value;
$messageid = $dice->result->message_id;
sleep(4); 
bot('editMessageReplyMarkup',[
    'chat_id'=> $chat_id,
    'message_id'=>$messageid,
	   'reply_markup' => json_encode([
                    'inline_keyboard' => [
    [['text' => "🎲 نتیجه تاس : $value", 'callback_data' => "none"]],                       
                    ]
                ])
    		]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
if($text == "ذکر امروز 📿"){
$zekr = file_get_contents("http://api.codebazan.ir/zekr/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📿➖➖➖➖

$zekr

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "حدیث 🕌"){
$hadis = file_get_contents("http://api.codebazan.ir/hadis/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🕌➖➖➖➖

$hadis

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "پسورد ساز ⛓️"){
$passwordSaz = file_get_contents("http://api.codebazan.ir/password/?length=12");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🔐➖➖➖➖

پسورد قدرتمند شما : $passwordSaz

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "الکی مثلا 💣"){
$alakimasalan = file_get_contents("http://api.codebazan.ir/jok/alaki-masalan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖💣➖➖➖➖

$alakimasalan

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "پَ نَ پَ 😆"){
$panapa = file_get_contents("http://api.codebazan.ir/jok/pa-na-pa/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖😆➖➖➖➖

$panapa

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "تلویزیون آنلاین 📺"){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"
پخش آنلاین شبکه های تلویزیونی ایران 👇
", 
'parse_mode'=>'HTML', 
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"شبکه یک",'url'=>'http://www.telewebion.com/#!/live/tv1'],['text'=>"شبکه دو",'url'=>'http://www.telewebion.com/#!/live/tv2 ']],
[['text'=>"شبکه سه",'url'=>'http://www.telewebion.com/#!/live/tv3'],['text'=>"شبکه چهار",'url'=>'http://www.telewebion.com/#!/live/tv4']],
[['text'=>"شبکه آموزش",'url'=>'http://www.telewebion.com/#!/live/amouzesh'],['text'=>"شبکه قرآن",'url'=>'http://www.telewebion.com/#!/live/quran']],
[['text'=>"شبکه سلامت",'url'=>'http://www.telewebion.com/#!/live/salamat'],['text'=>"شبکه نسیم",'url'=>'http://www.telewebion.com/#!/live/nasim']],
[['text'=>"شبکه مستند",'url'=>'http://www.telewebion.com/#!/live/mostanad'],['text'=>"شبکه افق",'url'=>'http://www.telewebion.com/#!/live/ofogh']],
[['text'=>"شبکه نمایش",'url'=>'http://www.telewebion.com/#!/live/namayesh'],['text'=>"شبکه آی فیلم",'url'=>'http://www.telewebion.com/#!/live/ifilm']],
[['text'=>"شبکه تهران",'url'=>'http://www.telewebion.com/#!/live/tehran ']],
] 
]) 
]); 
}
//========================================================//
if($text == "دانستنی 🐍"){
$Danestani = file_get_contents("http://api.codebazan.ir/danestani/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🐍➖➖➖➖

$Danestani

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "دیالوگ ماندگار 📃"){
$dialogue = file_get_contents("http://api.codebazan.ir/dialog/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📃➖➖➖➖

$dialogue

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "داستان کوتاه 📒"){
$dastan = file_get_contents("http://api.codebazan.ir/dastan/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📒➖➖➖➖

$dastan

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "چیستان 😃"){
$proxy = file_get_contents("http://api.codebazan.ir/danestani/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖😃➖➖➖➖

$proxy

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "تاریخ و ساعت ⏰"){
$tarek = file_get_contents("http://api.codebazan.ir/time-date/?td=all");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖⏰➖➖➖➖

$tarek

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "سه تیم بالای جدول لیگ ⚽️"){
$footbl = file_get_contents("http://mrblack.farahost.site/panel/football.php");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$footbl
"]); }
//========================================================//
if($text == "جوک 😂"){
$jok = file_get_contents("http://api.codebazan.ir/jok");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🤣➖➖➖➖

$jok

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "بیو ناب🍫"){
$BioNab = file_get_contents("https://api.codebazan.ir/bio/");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖📝➖➖➖➖

$BioNab

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
if($text == "خاطره 🤪"){
$Khatere = file_get_contents("http://api.codebazan.ir/jok/khatere");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
➖➖➖➖🤪➖➖➖➖

$Khatere

@$PaMicKee
➖➖➖➖➖➖➖➖➖
"]); }
//========================================================//
elseif($text == 'پینگ ربات 🗂' ){
$starttime = microtime(true);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"♻️ در حال بارگزاری اطلاعات و پینگ ...",
'parse_mode'=>"HTML",
]);
$endtime = (microtime(true) - $starttime);
$telegram_ping = substr($endtime, 0, -11);
$domain = $_SERVER['SERVER_NAME'];
$load = sys_getloadavg();
$mem = getMUsage();
$ver = phpversion();
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"اطلاعات دریافت شد ✅

🚀 پینگ تلگرام : $telegram_ping ms
📉 پینگ ربات : $load[0]
📌 ورژن پی اچ پی : $ver
📁 میزان مصرف حافظه : $mem",
'parse_mode'=>"HTML",
]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
elseif($text == "🖥️"){
$profile = "https://telegram.me/$username";
 bot('sendphoto',[
'chat_id' => $chat_id,
'photo'=>$profile,
'caption' =>"عکس پروفایل شما 👆

👮‍♂ نام شما : $first_name
🚸 نام خانوادگی شما : $last_name
🔰 ایدی شما : @$username
🆔 ایدی عددی شما : $chat_id

",
'reply_to_message_id'=>$message_id,
	 ]); 
	}

//========================================================//
elseif($text == "/panel" or $text == "پنل"){
if($from_id == $Dev){
bot('sendMessage', [
'chat_id' =>$chat_id,
'text' =>"مدیر عزیز به پنل مدیریت خوش آمدید 🌹",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"آمار ربات 📊"]],
[['text'=>"عضو های ربات 👥"]], 
[['text'=>"روشن کردن ✅"],['text'=>"خاموش کردن 📛"]],
[['text'=>"پینگ ربات 🗂"]], 
[['text'=>"متن بازگشت ✍"],['text'=>"متن استارت ✍"]],
[['text'=>"متن ارسال پشتیبانی ✍"],['text'=>"متن اسپانسر ✍"]],
[['text'=>"متن رسید پشتیبانی ✍"]], 
[['text'=>"پیام به کاربر 👤"],['text'=>"پیام همگانی 📨"]],
[['text'=>"🔙 بازگشت"]],  
],
'resize_keyboard'=>true
])
]);
file_put_contents("dataPaMicK/$from_id/step.txt","none");
}else{
sendMessage($chat_id,"شما ادمین نیستی که 😐","HTML");
}
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
elseif($text == "پیام به کاربر 👤"){
file_put_contents("dataPaMicK/$from_id/step.txt","idnum1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا ایدی عددی کاربر رو ارسال کن 🆔",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"/panel️"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "idnum1" && $text !="/panel️" ){
file_put_contents("dataPaMicK/$from_id/step.txt","sendpem");
file_put_contents("dataPaMicK/$from_id/idnum.txt","$text");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا پیام خودتو ارسال کن 📝",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"/panel️"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step == "sendpem" && $text !="/panel️" ){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
file_put_contents("dataPaMicK/$from_id/ersalpm.txt","$text");
$ersalpm = file_get_contents("dataPaMicK/$from_id/ersalpm.txt");
$info = file_get_contents("dataPaMicK/$from_id/idnum.txt");
bot('sendMessage',[
'chat_id'=>$info,
'text'=>"
🔖 شما یه پیام از پشتیبانی دریافت کرده اید 

پیام مدیر : $ersalpm 
 
",
'parse_mode'=>'HTML',
]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما با موفقیت برای کاربر ارسال شد 👮‍♂️",
'parse_mode'=>"HTML",  
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'پیام به کاربر 👤']],
[['text'=>"/panel"]],
],
'resize_keyboard'=>true,
])
]);
}
//========================================================//
 elseif($text == "بکاپ فایل اصلی 🗂" && $chat_id == $Dev ){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("PvPaMicK.php"),
'caption'=>"بکاپ از فایل اصلی 🗂
@$PaMicKee"
]);
}
//========================================================//
elseif($text == 'بکاپ دیتا 🗂' && $chat_id == $Dev){
Ziper('admin','admin.zip');
bot('sendDocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile('admin.zip'),
'caption'=>'بکاپ از فایل بات 🗂
',
]);bot('sendmessage',[     
'chat_id'=>$from_id,
'text'=>"❌️ به دلیل افزایش امنیت بکاپ از هاست پاک شد!",
]);	 
unlink('admin.zip');
}
//========================================================//
elseif($text == "متن بازگشت ✍" && $chat_id == $Dev){
file_put_contents("dataPaMicK/$from_id/step.txt","textback");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❗ متن برگشت را ارسال کنید
ID ایدی عددی کاربر
",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step =="textback" && $text !="پنل" ){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
file_put_contents("admin/textback.json",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت تنظیم شد 📂",
]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
//========================================================//
elseif($text == "خاموش کردن 📛"&& $from_id == $Dev){
file_put_contents("dataPaMicK/onof.txt","off");
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"خاموش شدم 😢",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"آمار ربات 📊"]],
[['text'=>"متن بازگشت ✍"],['text'=>"متن استارت ✍"]],
[['text'=>"عضو های ربات 👥"]], 
[['text'=>"روشن کردن ✅"],['text'=>"خاموش کردن 📛"]],
[['text'=>"پینگ ربات 🗂"]], 
[['text'=>"متن ارسال پشتیبانی ✍"],['text'=>"متن اسپانسر ✍"]],
[['text'=>"متن رسید پشتیبانی ✍"]], 
[['text'=>"بکاپ فایل اصلی 🗂"],['text'=>"پیام به کاربر 👤"]],
[['text'=>"پیام همگانی 📨"],['text'=>"بکاپ دیتا 🗂"]],
[['text'=>"🔙 بازگشت"]],  
],
])
]);
}
//========================================================//
elseif($text == "روشن کردن ✅"&& $from_id == $Dev){
file_put_contents("dataPaMicK/onof.txt","on");
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"روشن شدم 💋",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"آمار ربات 📊"]],
[['text'=>"متن بازگشت ✍"],['text'=>"متن استارت ✍"]],
[['text'=>"عضو های ربات 👥"]], 
[['text'=>"روشن کردن ✅"],['text'=>"خاموش کردن 📛"]],
[['text'=>"پینگ ربات 🗂"]], 
[['text'=>"متن ارسال پشتیبانی ✍"],['text'=>"متن اسپانسر ✍"]],
[['text'=>"متن رسید پشتیبانی ✍"]], 
[['text'=>"بکاپ فایل اصلی 🗂"],['text'=>"پیام به کاربر 👤"]],
[['text'=>"پیام همگانی 📨"],['text'=>"بکاپ دیتا 🗂"]],
[['text'=>"🔙 بازگشت"]],  
],
])
]);
}
//========================================================//
elseif($text == "متن استارت ✍" && $chat_id == $Dev){
file_put_contents("dataPaMicK/$from_id/step.txt","textstarttt");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❗ متن استارت را ارسال کنید
ID ایدی عددی کاربر
",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step =="textstarttt" && $text !="پنل" ){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
file_put_contents("admin/textstarttt.json",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت تنظیم شد 📂",
]);
}
//========================================================//
elseif($text == "متن اسپانسر ✍" && $chat_id == $Dev){
file_put_contents("dataPaMicK/$from_id/step.txt","textspanser");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❗ متن اسپانسر را ارسال کنید
ID ایدی عددی کاربر
",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step =="textspanser" && $text !="پنل" ){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
file_put_contents("admin/textspanser.json",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت تنظیم شد 📂",
]);
}
//========================================================//
 elseif($text == "عضو های ربات 👥" && $chat_id == $Dev ){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("MMBER.txt"),
'caption'=>"لیست عضو های ربات 👥
@$PaMicKee"
]);
}
//========================================================//
elseif ($text == "آمار ربات 📊"){
$user = file_get_contents("MMBER.txt");
$member_id = explode("\n",$user);
$member_count = count($member_id) -1;
bot('sendMessage',[
'chat_id' => $Dev,
'text' => "تعداد اعضای ربات : $member_count",
'parse_mode' => 'HTML'
]);
}
//========================================================//
elseif($text == "متن رسید پشتیبانی ✍" && $chat_id == $Dev){
file_put_contents("dataPaMicK/$from_id/step.txt","textresid");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❗ متن استارت را ارسال کنید
ID ایدی عددی کاربر
",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step =="textresid" && $text !="پنل" ){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
file_put_contents("admin/textresid.json",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت تنظیم شد 📂",
]);
}
//========================================================//
elseif($text == "متن ارسال پشتیبانی ✍" && $chat_id == $Dev){
file_put_contents("dataPaMicK/$from_id/step.txt","textersal");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❗ متن اسپانسر را ارسال کنید
ID ایدی عددی کاربر
",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"پنل"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif($step =="textersal" && $text !="پنل" ){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
file_put_contents("admin/textersal.json",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"با موفقیت تنظیم شد 📂",
]);
}
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
elseif($text == "پیام همگانی 📨"){
file_put_contents("dataPaMicK/$from_id/step.txt","pm");
bot('sendMessage',[
'chat_id'=>$Dev,
'text'=>"📨 | پیام خود را ارسال کنید !",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'پنل']],
],
'resize_keyboard'=>true
])
]);
}
elseif($step == "pm" && $text != "پنل"){
file_put_contents("dataPaMicK/$from_id/step.txt","none");
bot('sendMessage',[
'chat_id'=>$Dev,
'text'=>"📥 | پیام شما با موفقیت ارسال شد !",
]);
$all_member = fopen( "MMBER.txt", "r");
while( !feof( $all_member)){
$user = fgets( $all_member);
sendMessage($user,$text,"html");
}
}
//========================================================//
/*
اپن شد توسط تیم پامیک : @PaMicK
اصکی میری منبع بزن
*/
unlink('error_log');
?>